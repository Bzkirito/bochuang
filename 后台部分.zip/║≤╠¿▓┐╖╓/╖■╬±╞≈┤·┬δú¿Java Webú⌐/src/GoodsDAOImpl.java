import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.zip.DataFormatException;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.IntArraySerializer;

public class GoodsDAOImpl implements GoodsDAO{
	@Override
	public JSONArray  getGoodsByid(String id) {
		String sql = "select * from information where id='"+ id +"'";
		Connection conn = DBUtils.open();
		Goods g = new Goods();
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery(sql);
			ResultSetMetaData md = rs.getMetaData();
			JSONArray jsonArray = new JSONArray();
			if(rs.next())
			{
				JSONObject eventsObject = new JSONObject();
				eventsObject.put("name",rs.getString("name"));
				eventsObject.put("shelves",rs.getString("shelves"));
				eventsObject.put("spec",rs.getString("spec"));
				eventsObject.put("img",rs.getString("img"));
				eventsObject.put("findate",rs.getString("findate"));
				eventsObject.put("price",rs.getString("price"));
				eventsObject.put("spec",rs.getString("spec"));
				eventsObject.put("inventory",rs.getString("inventory"));
				jsonArray.add(eventsObject);
			}
			return jsonArray;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public JSONArray getGoodsByCode(String code) {
		String sql = "select * from information where Fcode='a"+ code +"'";
		Connection conn = DBUtils.open();
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery(sql);
			ResultSetMetaData md = rs.getMetaData();
			JSONArray jsonArray = new JSONArray();
			while(rs.next())
			{		
				JSONObject eventsObject = new JSONObject();
				eventsObject.put("name",rs.getString("name"));
				eventsObject.put("shelves",rs.getString("shelves"));
				eventsObject.put("spec",rs.getString("spec"));
				eventsObject.put("img",rs.getString("img"));
				eventsObject.put("findate",rs.getString("findate"));
				eventsObject.put("price",rs.getString("price"));
				eventsObject.put("spec",rs.getString("spec"));
				eventsObject.put("inventory",rs.getString("inventory"));
				jsonArray.add(eventsObject);
			}
			return jsonArray;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@Override
	public boolean get(List<User> u) {
		int size  = u.size();
		int sum_price = 0;
		String sql = "select * from inventory where rfid = ?";
		Connection conn =  DBUtils.open();
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			for(int i=0;i<size;i++)
			{
				System.out.println(u.get(i).getRfid());
				pstmt.setString(1,u.get(i).getRfid());
				ResultSet rs = pstmt.executeQuery();
				if(rs.next())
				{
					String code = rs.getString("code");
					String name = rs.getString("name");
					String spec = rs.getString("spec");
					String price = rs.getString("price");
					String img = rs.getString("img");
					Date date = new Date();   
					SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");    
					String date_s = dateFormat.format(date);
					sum_price += Integer.parseInt(price);
					add(code, name, spec, price, date_s, img);
				}
			}
			int balance = getBalance() - sum_price;
			if(balance >= 0)
			{
				setBalance(balance);
				return true;
			}
			else 
				return false;
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			DBUtils.close(conn);
		}
		return false;
	}
	
	@Override
	public void add(String code, String name,String spec,String price,String date,String img) {
		String sql = "insert into Userdata(code,name,spec,price,date,img)values(?,?,?,?,?,?)";
		Connection conn =  DBUtils.open();
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, code);
			pstmt.setString(2, name);
			pstmt.setString(3, spec);
			pstmt.setString(4, price);
			pstmt.setString(5, date);
			pstmt.setString(6, img);
			pstmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			DBUtils.close(conn);
		}
	}

	@Override
	public JSONArray getGoodsByTCode(String TCode) {
		String sql = "select * from information where TCode='" + TCode + "'";
		Connection conn = DBUtils.open();
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery(sql);
			ResultSetMetaData md = rs.getMetaData();
			JSONArray jsonArray = new JSONArray();
			while(rs.next())
			{		
				JSONObject eventsObject = new JSONObject();
				eventsObject.put("name",rs.getString("name"));
				eventsObject.put("shelves",rs.getString("shelves"));
				eventsObject.put("spec",rs.getString("spec"));
				eventsObject.put("img",rs.getString("img"));
				eventsObject.put("findate",rs.getString("findate"));
				eventsObject.put("price",rs.getString("price"));
				eventsObject.put("spec",rs.getString("spec"));
				eventsObject.put("inventory",rs.getString("inventory"));
				jsonArray.add(eventsObject);
			}
			return jsonArray;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	

	@Override
	public JSONArray getGoodsByRfid(String rfid) {
		String sql = "select * from inventory where rfid = '" + rfid + "'";
		Connection conn = DBUtils.open();
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery(sql);
			ResultSetMetaData md = rs.getMetaData();
			JSONArray jsonArray = new JSONArray();
			while(rs.next())
			{		
				JSONObject eventsObject = new JSONObject();
				eventsObject.put("name",rs.getString("name"));
				eventsObject.put("shelves",rs.getString("shelves"));
				eventsObject.put("spec",rs.getString("spec"));
				eventsObject.put("img",rs.getString("img"));
				eventsObject.put("findate",rs.getString("findate"));
				eventsObject.put("price",rs.getString("price"));
				eventsObject.put("spec",rs.getString("spec"));
				eventsObject.put("rfid", rfid);
				jsonArray.add(eventsObject);
			}
			return jsonArray;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public int getBalance() {
		Connection conn = DBUtils.open();
		String sql = "select balance from user";
		try {
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			if(rs.next())
			{
				int balance = rs.getInt("balance");
				return balance;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			DBUtils.close(conn);
		}
		return -1;
	}

	@Override
	public void setBalance(int balance) {
		System.out.println("balance : " + balance + "元");
		Connection conn = DBUtils.open();
		String sql = "update user set balance = '" + balance + "'";
		try {
			Statement stmt = conn.createStatement();
			stmt.executeUpdate(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			DBUtils.close(conn);
		}
		
	}
	@Override
	public boolean matchusernameandpassword(String username,String password){
		Connection conn = DBUtils.open();
		String sql = "select * from user where account = '"+ username + "' and password = '" + password + "'";
		try{
			PreparedStatement pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery(sql);
			while(rs.next()){
				return true;
			}
		}catch (SQLException e){
			e.printStackTrace();
		}finally{
			DBUtils.close(conn);
		}
		return false;
	}

	@Override
	public String[] getKind() {
		String sql = "select name from kind";
		Connection conn = DBUtils.open();
		int i = 0;
		try {
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			String[] name = new String[rs.getRow()];
			while(rs.next())
			{
				name[i] = rs.getString("name");
			}
			return name;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public int getInventoryByTCode(String TCode) {
		String sql = "select count(*) from inventory where TCode = '" + TCode + "'";
		//String sql = "select sum(case when TCode= '" + TCode + "' then 1 else 0 end) as a1 from inventory";
		int inventory = 0;
		Connection conn = DBUtils.open();
		try {
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			if(rs.next())
				inventory = rs.getInt(1);
			return inventory;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return 0;
	}

	@Override
	public int getInventoryByname(String name) {
		String sql = "select count(*) from inventory where name = '" + name + "'";
		//String sql = "select sum(case when TCode= '" + TCode + "' then 1 else 0 end) as a1 from inventory";
		int inventory = 0;
		Connection conn = DBUtils.open();
		try {
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			if(rs.next())
				inventory = rs.getInt(1);
			return inventory;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return 0;
	}

	@Override
	public void setInventory(String name) {
		int inventory = getInventoryByname(name);
		System.out.println(name+inventory);
		String sql = "update information set inventory =" + inventory + " where name ='" + name + "'";
		System.out.println(sql);
		Connection conn = DBUtils.open();
		try {
			Statement stmt = conn.createStatement();
			stmt.executeUpdate(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}