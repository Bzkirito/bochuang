import java.sql.ResultSet;
import java.util.List;
import com.alibaba.fastjson.*;

public interface GoodsDAO {
	public void add(String code, String name,String spec,String price,String date,String img);  //增加用户商品购买记录
	public boolean get(List<User> u);   //获取用户购买商品信息，并判断用户余额是否充足，最后调用add增加用户商品购买记录
	public JSONArray getGoodsByid(String id);  //根据商品id获取商品信息
	public JSONArray getGoodsByCode(String code);  //根据商品Code获取商品信息
	public JSONArray getGoodsByTCode(String Tcode);  //根据商品条形码获取商品信息
	public JSONArray getGoodsByRfid(String rfid);  //根据商品Rfid获取商品信息
	public void setBalance(int balance);  //修改用户余额（购买商品后）
	public int getBalance();  //获取用户余额
	public boolean matchusernameandpassword(String username,String password);  //根据帐号密码进行登录
	public String[] getKind();  //获取商品种类信息
	public int getInventoryByTCode(String TCode); //根据商品条形码获取商品库存
	public int getInventoryByname(String name);  //根据商品名获取商品库存
	public void setInventory(String name);
}
