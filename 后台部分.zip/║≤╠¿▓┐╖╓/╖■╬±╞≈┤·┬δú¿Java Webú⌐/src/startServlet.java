import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/startServlet")
public class startServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		String sql = "select request from loginservice";
		Connection conn = DBUtils.open();
		try {
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			PrintWriter out = response.getWriter();
			if (rs.next()) {
				out.print(rs.getInt(1));
			}
			out.flush();
			out.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtils.close(conn);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		String sql = "select request from loginservice";
		String a = request.getParameter("a");
		System.out.println("a = " + a);
		Connection conn = DBUtils.open();
		PrintWriter out = response.getWriter();
		
		if (a.equals("0")) 
		{
			sql = "update loginservice set request = '0' ";
			try
			{
				System.out.println("in 0");
				Statement stmt = conn.createStatement();
				stmt.execute(sql);
			} 
			catch (SQLException e) 
			{
				e.printStackTrace();
			} 
			finally {
				DBUtils.close(conn);
			}
		} 
		else if(a.equals("1"))
		{
			try
			{
				Statement stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery(sql);
				if(rs.next())
				{
					System.out.println("rs = " + rs.getString(1)); 
					if(rs.getString("request").equals("1"))
					{
						System.out.println("in 1");
						out.print("success");
					}
					else
					{
						out.print("error");
					}
				}
			} catch (SQLException e) 
			{
				e.printStackTrace();
			} finally {
				DBUtils.close(conn);
			}
			
		}
		else if(a.equals("2"))
		{
			System.out.println("in 2");
			request.getRequestDispatcher("CommendServlet").forward(request, response);
		}
		else
		{
			System.out.println("in another");
			Statement stmt;
			try {
				stmt = conn.createStatement();
				stmt.executeUpdate("update loginservice set request = '1' ");
				out.print("success");
			} catch (SQLException e) {
				e.printStackTrace();
			} finally{
				DBUtils.close(conn);
			}
		}
		/*
		 * try { Statement stmt = conn.createStatement(); stmt.execute(sql); }
		 * catch (SQLException e) { e.printStackTrace(); }finally {
		 * DBUtils.close(conn); }
		 */

	}
}
