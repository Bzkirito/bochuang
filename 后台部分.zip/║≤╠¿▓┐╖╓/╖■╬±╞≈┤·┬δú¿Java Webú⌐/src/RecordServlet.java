import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Statement;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.alibaba.fastjson.JSONArray;import com.alibaba.fastjson.JSONObject;

@WebServlet("/RecordServlet")
public class RecordServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		String user = request.getParameter("a");
		System.out.println(user);
		PrintWriter out = response.getWriter();
		JSONArray jsonArray = new JSONArray();
		List<User> person = jsonArray.parseArray(user, User.class);
		GoodsDAO gd = new GoodsDAOImpl();
		if(person != null)
		{
			if(gd.get(person))
				out.print("success");
			else
				out.print("fail");
		}
	}
}
