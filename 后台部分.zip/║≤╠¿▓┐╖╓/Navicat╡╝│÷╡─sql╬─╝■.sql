/*
 Navicat Premium Data Transfer

 Source Server         : CLOUD_NOTE
 Source Server Type    : MySQL
 Source Server Version : 50714
 Source Host           : localhost:3306
 Source Schema         : bcb

 Target Server Type    : MySQL
 Target Server Version : 50714
 File Encoding         : 65001

 Date: 03/06/2018 15:41:45
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for discount
-- ----------------------------
DROP TABLE IF EXISTS `discount`;
CREATE TABLE `discount`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Fkind` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `kind` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `Fprice` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `price` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 19 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of discount
-- ----------------------------
INSERT INTO `discount` VALUES (17, '酒水饮料', '饮料', '红牛', '5', '4');
INSERT INTO `discount` VALUES (16, '酒水饮料', '饮料', '绿茶', '3', '2.5');
INSERT INTO `discount` VALUES (15, '酒水饮料', '饮料', '冰红茶', '3', '2');
INSERT INTO `discount` VALUES (18, '酒水饮料', '饮料', '水溶C', '5', '4.5');

-- ----------------------------
-- Table structure for information
-- ----------------------------
DROP TABLE IF EXISTS `information`;
CREATE TABLE `information`  (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `Fcode` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `code` varchar(20) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `spec` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `price` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT '0',
  `date` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT '2018',
  `findate` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `shelves` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `img` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `TCode` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `inventory` int(11) UNSIGNED NULL DEFAULT 0,
  `Fkind` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `kind` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 98 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of information
-- ----------------------------
INSERT INTO `information` VALUES (18, 'a1', 'a11', '冰红茶', '500ml', '2', '2018年', '6个月', 'A-1', 'http://192.168.1.107/a1a1.jpg', '6922507005019', 0, '酒水饮料', '饮料');
INSERT INTO `information` VALUES (19, 'a1', 'a11', '绿茶', '500ml', '2.5', '2018年', '12个月', 'A-1', 'http://192.168.1.107/a1a2.jpg', '6922507005163', 0, '酒水饮料', '饮料');
INSERT INTO `information` VALUES (20, 'a1', 'a11', '红牛', '330ml', '4', '2018年', '24个月', 'A-2', 'http://192.168.1.107/a1a3.jpg', NULL, 0, '酒水饮料', '饮料');
INSERT INTO `information` VALUES (21, 'a1', 'a11', '咖啡', '330ml', '5', '2018年', '24个月', 'A-2', 'http://192.168.1.107/a1a4.jpg', NULL, 0, '酒水饮料', '饮料');
INSERT INTO `information` VALUES (22, 'a1', 'a11', '水溶C', '550ml', '4.5', '2018年', '12个月', 'A-3', 'http://192.168.1.107/a1a5.jpg', '6921168500970', 0, '酒水饮料', '饮料');
INSERT INTO `information` VALUES (23, 'a1', 'a11', '冰糖山楂', '500ml', '3', '2018年', '12个月', 'A-3', 'http://192.168.1.107/a1a6.jpg', NULL, 0, '酒水饮料', '饮料');
INSERT INTO `information` VALUES (24, 'a2', 'a22', '毛巾', '1个', '10', '2018年', '无', 'B-1', 'http://192.168.1.107/a2a1.jpg', NULL, 0, '酒水饮料', '家纺');
INSERT INTO `information` VALUES (25, 'a2', 'a21', '面巾纸', '1个', '1', '2018年', '无', 'B-1', 'http://192.168.1.107/a2a2.jpg', NULL, 0, '家居', '日用');
INSERT INTO `information` VALUES (26, 'a2', 'a21', '花露水', '1个', '5', '2018年', '无', 'B-2', 'http://192.168.1.107/a2a3.jpg', NULL, 0, '家居', '日用');
INSERT INTO `information` VALUES (27, 'a2', 'a21', '卫生巾', '1个', '20', '2018年', '无', 'B-2', 'http://192.168.1.107/a2a4.jpg', NULL, 0, '家居', '日用');
INSERT INTO `information` VALUES (28, 'a2', 'a23', '洗发水', '1个', '10', '2018年', '无', 'B-3', 'http://192.168.1.107/a2a5.jpg', NULL, 0, '家居', '洗浴');
INSERT INTO `information` VALUES (29, 'a2', 'a23', '牙刷', '1个', '3', '2018年', '无', 'B-3', 'http://192.168.1.107/a2a6.jpg', NULL, 0, '家居', '洗浴');
INSERT INTO `information` VALUES (30, 'a3', 'a31', '饼干', '1箱', '3', '2018年', '无', 'C-1', 'http://192.168.1.107/a3a1.jpg', NULL, 0, '食品', '休闲食品');
INSERT INTO `information` VALUES (31, 'a3', 'a32', '坚果', '1袋', '20', '2018年', '无', 'C-1', 'http://192.168.1.107/a3a2.jpg', NULL, 0, '食品', '营养零食');
INSERT INTO `information` VALUES (32, 'a3', 'a32', '罐头', '1瓶', '8', '2018年', '无', 'C-2', 'http://192.168.1.107/a3a3.jpg', NULL, 0, '食品', '营养零食');
INSERT INTO `information` VALUES (33, 'a3', 'a31', '巧克力', '1盒', '0', '2018年', '无', 'C-2', 'http://192.168.1.107/a3a4.jpg', NULL, 0, '食品', '休闲食品');
INSERT INTO `information` VALUES (34, 'a3', 'a31', '威化', '1盒', '0', '2018年', '无', 'C-3', 'http://192.168.1.107/a3a5.jpg', NULL, 0, '食品', '休闲食品');
INSERT INTO `information` VALUES (35, 'a3', 'a31', '蘑菇力', '1盒', '0', '2018年', '无', 'C-3', 'http://192.168.1.107/a3a6.jpg', NULL, 0, '食品', '休闲食品');
INSERT INTO `information` VALUES (36, 'a4', 'a45', '运动鞋', '1双', '0', '2018年', '无', 'D-1', 'http://192.168.1.107/a4a1.jpg', NULL, 0, '鞋服包', '鞋');
INSERT INTO `information` VALUES (37, 'a4', 'a42', '睡衣', '1套', '0', '2018年', '无', 'D-1', 'http://192.168.1.107/a4a2.jpg', NULL, 0, '鞋服包', '女装');
INSERT INTO `information` VALUES (38, 'a4', 'a44', '女包', '1个', '0', '2018年', '无', 'D-2', 'http://192.168.1.107/a4a3.jpg', NULL, 0, '鞋服包', '包');
INSERT INTO `information` VALUES (39, 'a4', 'a41', '文胸', '1个', '0', '2018年', '无', 'D-2', 'http://192.168.1.107/a4a4.jpg', NULL, 0, '鞋服包', '女装');
INSERT INTO `information` VALUES (40, 'a4', 'a41', '内裤', '1个', '0', '2018年', '无', 'D-3', 'http://192.168.1.107/a4a5.jpg', NULL, 0, '鞋服包', '女装');
INSERT INTO `information` VALUES (41, 'a4', 'a43', '围巾', '1条', '0', '2018年', '无', 'D-3', 'http://192.168.1.107/a4a6.jpg', NULL, 0, '鞋服包', '针织品');
INSERT INTO `information` VALUES (42, 'a5', 'a52', '酱油', '1瓶', '0', '2018年', '24个月', 'E-1', 'http://192.168.1.107/a5a1.jpg', NULL, 0, '日杂', '调味品');
INSERT INTO `information` VALUES (43, 'a5', 'a52', '豆油', '1桶', '0', '2018年', '24个月', 'E-1', 'http://192.168.1.107/a5a2.jpg', NULL, 0, '日杂', '粮油');
INSERT INTO `information` VALUES (44, 'a5', 'a51', '大米', '1袋', '0', '2018年', '36个月', 'E-2', 'http://192.168.1.107/a5a3.jpg', NULL, 0, '日杂', '粮油');
INSERT INTO `information` VALUES (45, 'a5', 'a51', '面粉', '1袋', '0', '2018年', '36个月', 'E-2', 'http://192.168.1.107/a5a4.jpg', NULL, 0, '日杂', '粮油');
INSERT INTO `information` VALUES (46, 'a3', 'a33', '方便面', '1包', '0', '2018年', '6个月', 'E-3', 'http://192.168.1.107/a5a5.jpg', NULL, 0, '食品', '主食');
INSERT INTO `information` VALUES (47, 'a5', 'a52', '陈醋', '1瓶', '0', '2018年', '24个月', 'E-3', 'http://192.168.1.107/a5a6.jpg', NULL, 0, '日杂', '调味品');
INSERT INTO `information` VALUES (48, 'a6', 'a6', '飞机杯', '1盒', '0', '2018年', '无', 'F-1', 'http://192.168.1.107/a6a1.jpg', NULL, 0, NULL, NULL);
INSERT INTO `information` VALUES (49, 'a6', 'a6', '避孕套', '1盒', '0', '2018年', '无', 'F-1', 'http://192.168.1.107/a6a2.jpg', NULL, 0, NULL, NULL);
INSERT INTO `information` VALUES (50, 'a6', 'a6', 'AV棒', '1个', '0', '2018年', '无', 'F-2', 'http://192.168.1.107/a6a3.jpg', NULL, 0, NULL, NULL);
INSERT INTO `information` VALUES (51, 'a6', 'a6', '润滑液', '1瓶', '0', '2018年', '无', 'F-2', 'http://192.168.1.107/a6a4.jpg', NULL, 0, NULL, NULL);
INSERT INTO `information` VALUES (52, 'a6', 'a6', '跳蛋', '1个', '0', '2018年', '无', 'F-3', 'http://192.168.1.107/a6a5.jpg', NULL, 0, NULL, NULL);
INSERT INTO `information` VALUES (53, 'a6', 'a6', '锁精环', '1盒', '0', '2018年', '无', 'F-3', 'http://192.168.1.107/a6a6.jpg', NULL, 0, NULL, NULL);
INSERT INTO `information` VALUES (90, 'a1', 'a12', '农夫山泉', '550ml', '2', '2018', '24个月', 'A-4', 'http://192.168.1.107/a1a7.jpg', '6921168509256', 2, '酒水饮料', '水');
INSERT INTO `information` VALUES (91, 'a1', 'a11', '农夫果园', '500ml', '4', '2018', '12个月', 'A-5', 'http://192.168.1.107/a1a8.jpg', '6921168532001', 0, '酒水饮料', '饮料');
INSERT INTO `information` VALUES (92, 'a1', 'a11', '水溶C100', '445ml', '5', '2018', '12个月', 'A-6', 'http://192.168.1.107/a1a9.jpg', '6921168559244', 0, '酒水饮料', '饮料');
INSERT INTO `information` VALUES (93, 'a1', 'a11', '可口可乐', '600ml', '3', '2018', '9个月', 'A-7', 'http://192.168.1.107/a1a10.jpg', '6954767415772\r', 0, '酒水饮料', '饮料');
INSERT INTO `information` VALUES (96, 'a1', 'a11', '雪碧', '600ml', '3', '2018', '12个月', 'A-9', 'http://192.168.1.107/a1a12.jpg', '6954767434674', 0, '酒水饮料', '饮料');
INSERT INTO `information` VALUES (95, 'a1', 'a11', '美年达', '600ml', '3', '2018', '12个月', 'A-8', 'http://192.168.1.107/a1a11.jpg', '6939223900030', 5, '酒水饮料', '饮料');
INSERT INTO `information` VALUES (97, 'a1', 'a12', '康师傅矿泉水', '550', '1', '2018', '12个月', 'A-9', 'http://192.168.1.107/a1a13.jpg', '6922507005033', 0, '酒水饮料', '水');

-- ----------------------------
-- Table structure for information_ori
-- ----------------------------
DROP TABLE IF EXISTS `information_ori`;
CREATE TABLE `information_ori`  (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `Fcode` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `code` varchar(20) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `spec` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `price` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT '0',
  `date` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT '2018',
  `findate` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `shelves` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `img` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `TCode` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `inventory` int(11) UNSIGNED NULL DEFAULT 0,
  `Fkind` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `kind` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 98 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of information_ori
-- ----------------------------
INSERT INTO `information_ori` VALUES (18, 'a1', 'a11', '冰红茶', '500ml', '3', '2018年', '6个月', 'A-1', 'http://192.168.1.107/a1a1.jpg', '6922507005019', 0, '酒水饮料', '饮料');
INSERT INTO `information_ori` VALUES (19, 'a1', 'a11', '绿茶', '500ml', '3', '2018年', '12个月', 'A-1', 'http://192.168.1.107/a1a2.jpg', '6922507005163', 0, '酒水饮料', '饮料');
INSERT INTO `information_ori` VALUES (20, 'a1', 'a11', '红牛', '330ml', '5', '2018年', '24个月', 'A-2', 'http://192.168.1.107/a1a3.jpg', NULL, 0, '酒水饮料', '饮料');
INSERT INTO `information_ori` VALUES (21, 'a1', 'a11', '咖啡', '330ml', '5', '2018年', '24个月', 'A-2', 'http://192.168.1.107/a1a4.jpg', NULL, 0, '酒水饮料', '饮料');
INSERT INTO `information_ori` VALUES (22, 'a1', 'a11', '水溶C', '550ml', '5', '2018年', '12个月', 'A-3', 'http://192.168.1.107/a1a5.jpg', '6921168500970', 0, '酒水饮料', '饮料');
INSERT INTO `information_ori` VALUES (23, 'a1', 'a11', '冰糖山楂', '500ml', '3', '2018年', '12个月', 'A-3', 'http://192.168.1.107/a1a6.jpg', NULL, 0, '酒水饮料', '饮料');
INSERT INTO `information_ori` VALUES (24, 'a2', 'a22', '毛巾', '1个', '10', '2018年', '无', 'B-1', 'http://192.168.1.107/a2a1.jpg', NULL, 0, '酒水饮料', '家纺');
INSERT INTO `information_ori` VALUES (25, 'a2', 'a21', '面巾纸', '1个', '1', '2018年', '无', 'B-1', 'http://192.168.1.107/a2a2.jpg', NULL, 0, '家居', '日用');
INSERT INTO `information_ori` VALUES (26, 'a2', 'a21', '花露水', '1个', '5', '2018年', '无', 'B-2', 'http://192.168.1.107/a2a3.jpg', NULL, 0, '家居', '日用');
INSERT INTO `information_ori` VALUES (27, 'a2', 'a21', '卫生巾', '1个', '20', '2018年', '无', 'B-2', 'http://192.168.1.107/a2a4.jpg', NULL, 0, '家居', '日用');
INSERT INTO `information_ori` VALUES (28, 'a2', 'a23', '洗发水', '1个', '10', '2018年', '无', 'B-3', 'http://192.168.1.107/a2a5.jpg', NULL, 0, '家居', '洗浴');
INSERT INTO `information_ori` VALUES (29, 'a2', 'a23', '牙刷', '1个', '3', '2018年', '无', 'B-3', 'http://192.168.1.107/a2a6.jpg', NULL, 0, '家居', '洗浴');
INSERT INTO `information_ori` VALUES (30, 'a3', 'a31', '饼干', '1箱', '3', '2018年', '无', 'C-1', 'http://192.168.1.107/a3a1.jpg', NULL, 0, '食品', '休闲食品');
INSERT INTO `information_ori` VALUES (31, 'a3', 'a32', '坚果', '1袋', '20', '2018年', '无', 'C-1', 'http://192.168.1.107/a3a2.jpg', NULL, 0, '食品', '营养零食');
INSERT INTO `information_ori` VALUES (32, 'a3', 'a32', '罐头', '1瓶', '8', '2018年', '无', 'C-2', 'http://192.168.1.107/a3a3.jpg', NULL, 0, '食品', '营养零食');
INSERT INTO `information_ori` VALUES (33, 'a3', 'a31', '巧克力', '1盒', '0', '2018年', '无', 'C-2', 'http://192.168.1.107/a3a4.jpg', NULL, 0, '食品', '休闲食品');
INSERT INTO `information_ori` VALUES (34, 'a3', 'a31', '威化', '1盒', '0', '2018年', '无', 'C-3', 'http://192.168.1.107/a3a5.jpg', NULL, 0, '食品', '休闲食品');
INSERT INTO `information_ori` VALUES (35, 'a3', 'a31', '蘑菇力', '1盒', '0', '2018年', '无', 'C-3', 'http://192.168.1.107/a3a6.jpg', NULL, 0, '食品', '休闲食品');
INSERT INTO `information_ori` VALUES (36, 'a4', 'a45', '运动鞋', '1双', '0', '2018年', '无', 'D-1', 'http://192.168.1.107/a4a1.jpg', NULL, 0, '鞋服包', '鞋');
INSERT INTO `information_ori` VALUES (37, 'a4', 'a42', '睡衣', '1套', '0', '2018年', '无', 'D-1', 'http://192.168.1.107/a4a2.jpg', NULL, 0, '鞋服包', '女装');
INSERT INTO `information_ori` VALUES (38, 'a4', 'a44', '女包', '1个', '0', '2018年', '无', 'D-2', 'http://192.168.1.107/a4a3.jpg', NULL, 0, '鞋服包', '包');
INSERT INTO `information_ori` VALUES (39, 'a4', 'a41', '文胸', '1个', '0', '2018年', '无', 'D-2', 'http://192.168.1.107/a4a4.jpg', NULL, 0, '鞋服包', '女装');
INSERT INTO `information_ori` VALUES (40, 'a4', 'a41', '内裤', '1个', '0', '2018年', '无', 'D-3', 'http://192.168.1.107/a4a5.jpg', NULL, 0, '鞋服包', '女装');
INSERT INTO `information_ori` VALUES (41, 'a4', 'a43', '围巾', '1条', '0', '2018年', '无', 'D-3', 'http://192.168.1.107/a4a6.jpg', NULL, 0, '鞋服包', '针织品');
INSERT INTO `information_ori` VALUES (42, 'a5', 'a52', '酱油', '1瓶', '0', '2018年', '24个月', 'E-1', 'http://192.168.1.107/a5a1.jpg', NULL, 0, '日杂', '调味品');
INSERT INTO `information_ori` VALUES (43, 'a5', 'a52', '豆油', '1桶', '0', '2018年', '24个月', 'E-1', 'http://192.168.1.107/a5a2.jpg', NULL, 0, '日杂', '粮油');
INSERT INTO `information_ori` VALUES (44, 'a5', 'a51', '大米', '1袋', '0', '2018年', '36个月', 'E-2', 'http://192.168.1.107/a5a3.jpg', NULL, 0, '日杂', '粮油');
INSERT INTO `information_ori` VALUES (45, 'a5', 'a51', '面粉', '1袋', '0', '2018年', '36个月', 'E-2', 'http://192.168.1.107/a5a4.jpg', NULL, 0, '日杂', '粮油');
INSERT INTO `information_ori` VALUES (46, 'a3', 'a33', '方便面', '1包', '0', '2018年', '6个月', 'E-3', 'http://192.168.1.107/a5a5.jpg', NULL, 0, '食品', '主食');
INSERT INTO `information_ori` VALUES (47, 'a5', 'a52', '陈醋', '1瓶', '0', '2018年', '24个月', 'E-3', 'http://192.168.1.107/a5a6.jpg', NULL, 0, '日杂', '调味品');
INSERT INTO `information_ori` VALUES (48, 'a6', 'a6', '飞机杯', '1盒', '0', '2018年', '无', 'F-1', 'http://192.168.1.107/a6a1.jpg', NULL, 0, NULL, NULL);
INSERT INTO `information_ori` VALUES (49, 'a6', 'a6', '避孕套', '1盒', '0', '2018年', '无', 'F-1', 'http://192.168.1.107/a6a2.jpg', NULL, 0, NULL, NULL);
INSERT INTO `information_ori` VALUES (50, 'a6', 'a6', 'AV棒', '1个', '0', '2018年', '无', 'F-2', 'http://192.168.1.107/a6a3.jpg', NULL, 0, NULL, NULL);
INSERT INTO `information_ori` VALUES (51, 'a6', 'a6', '润滑液', '1瓶', '0', '2018年', '无', 'F-2', 'http://192.168.1.107/a6a4.jpg', NULL, 0, NULL, NULL);
INSERT INTO `information_ori` VALUES (52, 'a6', 'a6', '跳蛋', '1个', '0', '2018年', '无', 'F-3', 'http://192.168.1.107/a6a5.jpg', NULL, 0, NULL, NULL);
INSERT INTO `information_ori` VALUES (53, 'a6', 'a6', '锁精环', '1盒', '0', '2018年', '无', 'F-3', 'http://192.168.1.107/a6a6.jpg', NULL, 0, NULL, NULL);
INSERT INTO `information_ori` VALUES (90, 'a1', 'a12', '农夫山泉', '550ml', '2', '2018', '24个月', 'A-4', 'http://192.168.1.107/a1a7.jpg', '6921168509256', 2, '酒水饮料', '水');
INSERT INTO `information_ori` VALUES (91, 'a1', 'a11', '农夫果园', '500ml', '4', '2018', '12个月', 'A-5', 'http://192.168.1.107/a1a8.jpg', '6921168532001', 0, '酒水饮料', '饮料');
INSERT INTO `information_ori` VALUES (92, 'a1', 'a11', '水溶C100', '445ml', '5', '2018', '12个月', 'A-6', 'http://192.168.1.107/a1a9.jpg', '6921168559244', 0, '酒水饮料', '饮料');
INSERT INTO `information_ori` VALUES (93, 'a1', 'a11', '可口可乐', '600ml', '3', '2018', '9个月', 'A-7', 'http://192.168.1.107/a1a10.jpg', '6954767415772\r', 0, '酒水饮料', '饮料');
INSERT INTO `information_ori` VALUES (96, 'a1', 'a11', '雪碧', '600ml', '3', '2018', '12个月', 'A-9', 'http://192.168.1.107/a1a12.jpg', '6954767434674', 0, '酒水饮料', '饮料');
INSERT INTO `information_ori` VALUES (95, 'a1', 'a11', '美年达', '600ml', '3', '2018', '12个月', 'A-8', 'http://192.168.1.107/a1a11.jpg', '6939223900030', 5, '酒水饮料', '饮料');
INSERT INTO `information_ori` VALUES (97, 'a1', 'a12', '康师傅矿泉水', '550', '1', '2018', '12个月', 'A-9', 'http://192.168.1.107/a1a13.jpg', '6922507005033', 0, '酒水饮料', '水');

-- ----------------------------
-- Table structure for inventory
-- ----------------------------
DROP TABLE IF EXISTS `inventory`;
CREATE TABLE `inventory`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `spec` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `price` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `state` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT '0',
  `date` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT '2018',
  `findate` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `shelves` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `img` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `rfid` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 127 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of inventory
-- ----------------------------
INSERT INTO `inventory` VALUES (121, 'a1', '水溶C100', '445ml', '5', '0', '2018年5月14日', '12个月', 'A-6', 'http://192.168.1.107/a1a9.jpg', '4122320406614042161148');
INSERT INTO `inventory` VALUES (120, 'a1', '农夫果园', '500ml', '4', '0', '2018年5月13日', '12个月', 'A-5', 'http://192.168.1.107/a1a8.jpg', '4122320402267941161244');
INSERT INTO `inventory` VALUES (119, 'a1', '青梅', '600ml', '3', '0', '2018年5月13日', '12个月', 'A-8', 'http://192.168.1.107/a1a11.jpg', '41223204024219538161103');
INSERT INTO `inventory` VALUES (117, 'a1', '美年达', '600ml', '3', '0', '2018年5月9日', '12个月', 'A-8', 'http://192.168.1.107/a1a11.jpg', '41223204016221140161');
INSERT INTO `inventory` VALUES (114, 'a1', '美年达', '600ml', '3', '0', '2018年5月9日', '12个月', 'A-8', 'http://192.168.1.107/a1a11.jpg', '4122320401622114016141');
INSERT INTO `inventory` VALUES (112, 'a1', '雪碧', '445ml', '5', '0', '2018年5月9日', '12个月', 'A-6', 'http://192.168.1.107/a1a9.jpg', '412232040181114916160');
INSERT INTO `inventory` VALUES (115, 'a1', '美年达', '600ml', '3', '0', '2018年5月9日', '12个月', 'A-8', 'http://192.168.1.107/a1a11.jpg', '4122320403415550161');
INSERT INTO `inventory` VALUES (118, 'a1', '水溶C100', '445ml', '5', '0', '2018年5月13日', '12个月', 'A-6', 'http://192.168.1.107/a1a9.jpg', '4122320401942244916199');
INSERT INTO `inventory` VALUES (116, 'a1', '美年达', '600ml', '3', '0', '2018年5月9日', '12个月', 'A-8', 'http://192.168.1.107/a1a11.jpg', '41223204022615846161');
INSERT INTO `inventory` VALUES (110, 'a1', '水溶C100', '445ml', '5', '0', '2018年5月9日', '12个月', 'A-6', 'http://192.168.1.107/a1a9.jpg', '4122320406614042161');
INSERT INTO `inventory` VALUES (109, 'a1', '农夫山泉', '600ml', '2', '0', '2018年5月9日', '12个月', 'A-8', 'http://192.168.1.107/a1a7.jpg', '4122320403415550161251');
INSERT INTO `inventory` VALUES (122, 'a1', '农夫山泉', '600ml', '2', '0', '2018', '12', 'A-8', 'http://192.168.1.107/a1a7.jpg', '4122320401870391613');
INSERT INTO `inventory` VALUES (123, 'a1', '农夫果园', '500ml', '4', '0', '2018年5月31日', '12个月', 'A-5', 'http://192.168.1.107/a1a8.jpg', '41223B702267941161244');
INSERT INTO `inventory` VALUES (124, 'a1', '冰红茶', '500ml', '2', '0', '2018年5月31日', '6个月', 'A-1', 'http://192.168.1.107/a1a1.jpg', '4122320401781844816174');
INSERT INTO `inventory` VALUES (125, 'a1', '绿茶', '500ml', '2.5', '0', '2018年5月31日', '12个月', 'A-1', 'http://192.168.1.107/a1a2.jpg', '412232040146205451612');
INSERT INTO `inventory` VALUES (126, 'a1', '绿茶', '500ml', '2.5', '0', '2018年5月31日', '12个月', 'A-1', 'http://192.168.1.107/a1a2.jpg', '412232040178842161224');

-- ----------------------------
-- Table structure for kind
-- ----------------------------
DROP TABLE IF EXISTS `kind`;
CREATE TABLE `kind`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 33 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of kind
-- ----------------------------
INSERT INTO `kind` VALUES (30, '酒水饮料');
INSERT INTO `kind` VALUES (6, '书本');
INSERT INTO `kind` VALUES (27, '家居');
INSERT INTO `kind` VALUES (28, '食品');
INSERT INTO `kind` VALUES (31, '鞋服包');
INSERT INTO `kind` VALUES (32, '日杂');

-- ----------------------------
-- Table structure for loginservice
-- ----------------------------
DROP TABLE IF EXISTS `loginservice`;
CREATE TABLE `loginservice`  (
  `request` int(1) NOT NULL DEFAULT 0
) ENGINE = MyISAM CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Fixed;

-- ----------------------------
-- Records of loginservice
-- ----------------------------
INSERT INTO `loginservice` VALUES (1);

-- ----------------------------
-- Table structure for skind
-- ----------------------------
DROP TABLE IF EXISTS `skind`;
CREATE TABLE `skind`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Fkind` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 39 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of skind
-- ----------------------------
INSERT INTO `skind` VALUES (26, '酒水饮料', '饮料');
INSERT INTO `skind` VALUES (25, '酒水饮料', '水');
INSERT INTO `skind` VALUES (24, '酒水饮料', '酒');
INSERT INTO `skind` VALUES (5, '书本', 'Java');
INSERT INTO `skind` VALUES (6, '书本', 'Python');
INSERT INTO `skind` VALUES (13, '书本', 'C');
INSERT INTO `skind` VALUES (19, '家居', '日用');
INSERT INTO `skind` VALUES (20, '家居', '家纺');
INSERT INTO `skind` VALUES (21, '家居', '洗浴');
INSERT INTO `skind` VALUES (22, '食品', '休闲食品');
INSERT INTO `skind` VALUES (23, '食品', '营养零食');
INSERT INTO `skind` VALUES (30, '鞋服包', '女装');
INSERT INTO `skind` VALUES (29, '鞋服包', '男装');
INSERT INTO `skind` VALUES (31, '鞋服包', '针织品');
INSERT INTO `skind` VALUES (32, '鞋服包', '包');
INSERT INTO `skind` VALUES (33, '鞋服包', '鞋');
INSERT INTO `skind` VALUES (38, '日杂', '粮油');
INSERT INTO `skind` VALUES (35, '日杂', '调味品');
INSERT INTO `skind` VALUES (37, '食品', '主食');

-- ----------------------------
-- Table structure for tempinfo
-- ----------------------------
DROP TABLE IF EXISTS `tempinfo`;
CREATE TABLE `tempinfo`  (
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `price` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL
) ENGINE = MyISAM CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `password` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `balance` float(9, 0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 2 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES (1, '13420528712', '123456789', 1837);

-- ----------------------------
-- Table structure for userdata
-- ----------------------------
DROP TABLE IF EXISTS `userdata`;
CREATE TABLE `userdata`  (
  `id` int(11) NULL DEFAULT 1,
  `code` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `spec` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `price` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT '0',
  `date` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `img` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL
) ENGINE = MyISAM CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of userdata
-- ----------------------------
INSERT INTO `userdata` VALUES (1, 'a1', '冰红茶', '500ml', '3', '2015-10-10', 'http://192.168.1.107/a1a1.jpg');
INSERT INTO `userdata` VALUES (1, 'a1', '美年达', '600ml', '3', '2018-05-13', 'http://192.168.1.107/a1a11.jpg');
INSERT INTO `userdata` VALUES (1, 'a1', '美年达', '600ml', '3', '2018-05-13', 'http://192.168.1.107/a1a11.jpg');
INSERT INTO `userdata` VALUES (1, 'a1', '水溶C100', '445ml', '5', '2018-05-12', 'http://192.168.1.107/a1a9.jpg');
INSERT INTO `userdata` VALUES (1, 'a1', '美年达', '600ml', '3', '2018-05-12', 'http://192.168.1.107/a1a11.jpg');
INSERT INTO `userdata` VALUES (1, 'a1', '水溶C100', '445ml', '5', '2018-05-12', 'http://192.168.1.107/a1a9.jpg');
INSERT INTO `userdata` VALUES (1, 'a1', '美年达', '600ml', '3', '2018-05-12', 'http://192.168.1.107/a1a11.jpg');
INSERT INTO `userdata` VALUES (1, 'a1', '美年达', '600ml', '3', '2018-05-13', 'http://192.168.1.107/a1a11.jpg');
INSERT INTO `userdata` VALUES (1, 'a1', '美年达', '600ml', '3', '2018-05-12', 'http://192.168.1.107/a1a11.jpg');
INSERT INTO `userdata` VALUES (1, 'a1', '水溶C100', '445ml', '5', '2018-05-12', 'http://192.168.1.107/a1a9.jpg');
INSERT INTO `userdata` VALUES (1, 'a1', '美年达', '600ml', '3', '2018-05-13', 'http://192.168.1.107/a1a11.jpg');
INSERT INTO `userdata` VALUES (1, 'a1', '美年达', '600ml', '3', '2018-05-13', 'http://192.168.1.107/a1a11.jpg');
INSERT INTO `userdata` VALUES (1, 'a1', '美年达', '600ml', '3', '2018-05-13', 'http://192.168.1.107/a1a11.jpg');
INSERT INTO `userdata` VALUES (1, 'a1', '美年达', '600ml', '3', '2018-05-13', 'http://192.168.1.107/a1a11.jpg');
INSERT INTO `userdata` VALUES (1, 'a1', '美年达', '600ml', '3', '2018-05-13', 'http://192.168.1.107/a1a11.jpg');
INSERT INTO `userdata` VALUES (1, 'a1', '美年达', '600ml', '3', '2018-05-13', 'http://192.168.1.107/a1a11.jpg');
INSERT INTO `userdata` VALUES (1, 'a1', '美年达', '600ml', '3', '2018-05-13', 'http://192.168.1.107/a1a11.jpg');
INSERT INTO `userdata` VALUES (1, 'a1', '水溶C100', '445ml', '5', '2018-05-13', 'http://192.168.1.107/a1a9.jpg');
INSERT INTO `userdata` VALUES (1, 'a1', '水溶C100', '445ml', '5', '2018-05-13', 'http://192.168.1.107/a1a9.jpg');
INSERT INTO `userdata` VALUES (1, 'a1', '农夫果园', '500ml', '4', '2018-05-13', 'http://192.168.1.107/a1a8.jpg');
INSERT INTO `userdata` VALUES (1, 'a1', '水溶C100', '445ml', '5', '2018-05-14', 'http://192.168.1.107/a1a9.jpg');
INSERT INTO `userdata` VALUES (1, 'a1', '美年达', '600ml', '3', '2018-05-14', 'http://192.168.1.107/a1a11.jpg');
INSERT INTO `userdata` VALUES (1, 'a1', '美年达', '600ml', '3', '2018-05-14', 'http://192.168.1.107/a1a11.jpg');
INSERT INTO `userdata` VALUES (1, 'a1', '水溶C100', '445ml', '5', '2018-05-14', 'http://192.168.1.107/a1a9.jpg');
INSERT INTO `userdata` VALUES (1, 'a1', '美年达', '600ml', '3', '2018-05-14', 'http://192.168.1.107/a1a11.jpg');
INSERT INTO `userdata` VALUES (1, 'a1', '水溶C100', '445ml', '5', '2018-05-14', 'http://192.168.1.107/a1a9.jpg');
INSERT INTO `userdata` VALUES (1, 'a1', '美年达', '600ml', '3', '2018-05-15', 'http://192.168.1.107/a1a11.jpg');
INSERT INTO `userdata` VALUES (1, 'a1', '美年达', '600ml', '3', '2018-05-15', 'http://192.168.1.107/a1a11.jpg');
INSERT INTO `userdata` VALUES (1, 'a1', '美年达', '600ml', '3', '2018-05-15', 'http://192.168.1.107/a1a11.jpg');
INSERT INTO `userdata` VALUES (1, 'a1', '美年达', '600ml', '3', '2018-05-15', 'http://192.168.1.107/a1a11.jpg');
INSERT INTO `userdata` VALUES (1, 'a1', '美年达', '600ml', '3', '2018-05-15', 'http://192.168.1.107/a1a11.jpg');
INSERT INTO `userdata` VALUES (1, 'a1', '美年达', '600ml', '3', '2018-05-15', 'http://192.168.1.107/a1a11.jpg');
INSERT INTO `userdata` VALUES (1, 'a1', '美年达', '600ml', '3', '2018-05-15', 'http://192.168.1.107/a1a11.jpg');
INSERT INTO `userdata` VALUES (1, 'a1', '美年达', '600ml', '3', '2018-05-15', 'http://192.168.1.107/a1a11.jpg');
INSERT INTO `userdata` VALUES (1, 'a1', '美年达', '600ml', '3', '2018-05-15', 'http://192.168.1.107/a1a11.jpg');
INSERT INTO `userdata` VALUES (1, 'a1', '美年达', '600ml', '3', '2018-05-15', 'http://192.168.1.107/a1a11.jpg');
INSERT INTO `userdata` VALUES (1, 'a1', '美年达', '600ml', '3', '2018-05-15', 'http://192.168.1.107/a1a11.jpg');
INSERT INTO `userdata` VALUES (1, 'a1', '美年达', '600ml', '3', '2018-05-15', 'http://192.168.1.107/a1a11.jpg');
INSERT INTO `userdata` VALUES (1, 'a1', '美年达', '600ml', '3', '2018-05-15', 'http://192.168.1.107/a1a11.jpg');
INSERT INTO `userdata` VALUES (1, 'a1', '美年达', '600ml', '3', '2018-05-15', 'http://192.168.1.107/a1a11.jpg');
INSERT INTO `userdata` VALUES (1, 'a1', '美年达', '600ml', '3', '2018-05-15', 'http://192.168.1.107/a1a11.jpg');
INSERT INTO `userdata` VALUES (1, 'a1', '美年达', '600ml', '3', '2018-05-15', 'http://192.168.1.107/a1a11.jpg');
INSERT INTO `userdata` VALUES (1, 'a1', '美年达', '600ml', '3', '2018-05-15', 'http://192.168.1.107/a1a11.jpg');
INSERT INTO `userdata` VALUES (1, 'a1', '美年达', '600ml', '3', '2018-05-15', 'http://192.168.1.107/a1a11.jpg');
INSERT INTO `userdata` VALUES (1, 'a1', '美年达', '600ml', '3', '2018-05-15', 'http://192.168.1.107/a1a11.jpg');
INSERT INTO `userdata` VALUES (1, 'a1', '美年达', '600ml', '3', '2018-05-15', 'http://192.168.1.107/a1a11.jpg');
INSERT INTO `userdata` VALUES (1, 'a1', '美年达', '600ml', '3', '2018-05-15', 'http://192.168.1.107/a1a11.jpg');
INSERT INTO `userdata` VALUES (1, 'a1', '美年达', '600ml', '3', '2018-05-15', 'http://192.168.1.107/a1a11.jpg');
INSERT INTO `userdata` VALUES (1, 'a1', '农夫山泉', '600ml', '3', '2018-05-15', 'http://192.168.1.107/a1a7.jpg');
INSERT INTO `userdata` VALUES (1, 'a1', '农夫山泉', '600ml', '3', '2018-05-15', 'http://192.168.1.107/a1a7.jpg');
INSERT INTO `userdata` VALUES (1, 'a1', '农夫山泉', '600ml', '3', '2018-05-15', 'http://192.168.1.107/a1a7.jpg');
INSERT INTO `userdata` VALUES (1, 'a1', '水溶C100', '445ml', '5', '2018-05-15', 'http://192.168.1.107/a1a9.jpg');
INSERT INTO `userdata` VALUES (1, 'a1', '青梅', '600ml', '3', '2018-05-15', 'http://192.168.1.107/a1a11.jpg');
INSERT INTO `userdata` VALUES (1, 'a1', '美年达', '600ml', '3', '2018-05-15', 'http://192.168.1.107/a1a11.jpg');
INSERT INTO `userdata` VALUES (1, 'a1', '农夫果园', '500ml', '4', '2018-05-15', 'http://192.168.1.107/a1a8.jpg');
INSERT INTO `userdata` VALUES (1, 'a1', '农夫山泉', '600ml', '3', '2018-05-16', 'http://192.168.1.107/a1a7.jpg');
INSERT INTO `userdata` VALUES (1, 'a1', '青梅', '600ml', '3', '2018-05-16', 'http://192.168.1.107/a1a11.jpg');
INSERT INTO `userdata` VALUES (1, 'a1', '水溶C100', '445ml', '5', '2018-05-16', 'http://192.168.1.107/a1a9.jpg');
INSERT INTO `userdata` VALUES (1, 'a1', '美年达', '600ml', '3', '2018-05-16', 'http://192.168.1.107/a1a11.jpg');
INSERT INTO `userdata` VALUES (1, 'a1', '农夫果园', '500ml', '4', '2018-05-16', 'http://192.168.1.107/a1a8.jpg');
INSERT INTO `userdata` VALUES (1, 'a1', '农夫山泉', '600ml', '3', '2018-05-16', 'http://192.168.1.107/a1a7.jpg');
INSERT INTO `userdata` VALUES (1, 'a1', '农夫果园', '500ml', '4', '2018-06-03', 'http://192.168.1.107/a1a8.jpg');
INSERT INTO `userdata` VALUES (1, 'a1', '美年达', '600ml', '3', '2018-06-03', 'http://192.168.1.107/a1a11.jpg');
INSERT INTO `userdata` VALUES (1, 'a1', '农夫果园', '500ml', '4', '2018-06-03', 'http://192.168.1.107/a1a8.jpg');

SET FOREIGN_KEY_CHECKS = 1;
