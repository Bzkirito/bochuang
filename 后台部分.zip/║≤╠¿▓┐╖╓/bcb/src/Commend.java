import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.catalina.ant.FindLeaksTask;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

public class Commend {
	public static String getRS(){
		Connection conn = DBUtils.open();
		int[] array = new int[6];
		int maxIndex = 2;
		int maxValue = 0;
		String sql = "select sum(case when Fcode= 'a1' then 1 else 0 end) as a1,sum(case when Fcode in('a2') then 1 else 0 end)as a2,sum(case when Fcode in('a3') then 1 else 0 end)as a3,sum(case when Fcode in('a4') then 1 else 0 end)as a4,sum(case when Fcode in('a5') then 1 else 0 end)as a5,sum(case when Fcode in('a6') then 1 else 0 end)as a6 from userdata";
		try {
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			if(rs.next())
			{
				array[0] = rs.getInt("a1");
				array[1] = rs.getInt("a2");
				array[2] = rs.getInt("a3");
				array[3] = rs.getInt("a4");
				array[4] = rs.getInt("a5");
				array[5] = rs.getInt("a6");
			}
	        for (int i = 0; i < array.length; i++) {
	            if(maxValue < array[i]){
	                maxValue = array[i];
	                maxIndex = i+1;
	            }
	        }
			return ""+maxIndex;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return sql;
	}
		
		
	

}
