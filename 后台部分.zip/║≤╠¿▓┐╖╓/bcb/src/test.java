import java.text.SimpleDateFormat;
import java.util.Date;

import javax.xml.crypto.Data;

public class test {

	public static void main(String[] args) {
		Date myDate = new Date();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss"); 
		System.out.println(dateFormat.format(myDate));

	}

}
