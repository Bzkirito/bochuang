import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.zip.DataFormatException;

import javax.naming.spi.DirStateFactory.Result;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.IntArraySerializer;

public class GoodsDAOImpl implements GoodsDAO{
	@Override
	public JSONArray  getGoodsByid(String id) {
		String sql = "select * from information where id='"+ id +"'";
		Connection conn = DBUtils.open();
		Goods g = new Goods();
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery(sql);
			ResultSetMetaData md = rs.getMetaData();
			JSONArray jsonArray = new JSONArray();
			if(rs.next())
			{
				JSONObject eventsObject = new JSONObject();
				eventsObject.put("name",rs.getString("name"));
				eventsObject.put("shelves",rs.getString("shelves"));
				eventsObject.put("spec",rs.getString("spec"));
				eventsObject.put("img",rs.getString("img"));
				eventsObject.put("findate",rs.getString("findate"));
				eventsObject.put("price",rs.getString("price"));
				eventsObject.put("spec",rs.getString("spec"));
				eventsObject.put("inventory",rs.getString("inventory"));
				jsonArray.add(eventsObject);
			}
			return jsonArray;
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBUtils.close(conn);
		}
		return null;
	}

	@Override
	public JSONArray getGoodsByCode(String code) {
		String sql = "select * from information where Fcode='a"+ code +"'";
		Connection conn = DBUtils.open();
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery(sql);
			//ResultSetMetaData md = rs.getMetaData();
			JSONArray jsonArray = new JSONArray();
			while(rs.next())
			{		
				JSONObject eventsObject = new JSONObject();
				eventsObject.put("name",rs.getString("name"));
				eventsObject.put("shelves",rs.getString("shelves"));
				eventsObject.put("spec",rs.getString("spec"));
				eventsObject.put("img",rs.getString("img"));
				eventsObject.put("findate",rs.getString("findate"));
				eventsObject.put("price",rs.getString("price"));
				eventsObject.put("spec",rs.getString("spec"));
				eventsObject.put("inventory",rs.getString("inventory"));
				jsonArray.add(eventsObject);
			}
			return jsonArray;
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBUtils.close(conn);
		}
		return null;
	}
	
	@Override
	public boolean get(List<User> u) {
		int size  = u.size();
		System.out.println("size:" + size);
		float sum_price = 0;
		String sql = "select * from inventory where rfid = ?";
		Connection conn =  DBUtils.open();
		String code = null;
		String name = null;
		String spec = null;
		String price = null;
		String img = null;
		Date date = new Date();
		String date_s = null;
		String order = null;
		String Fcode = null;
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			for(int i=0;i<size;i++)
			{
				System.out.println(u.get(i).getRfid());
				pstmt.setString(1,u.get(i).getRfid());
				ResultSet rs = pstmt.executeQuery();
				if(rs.next())
				{
					price = rs.getString("price");  
					sum_price += Float.parseFloat(price);
					
				}
			}
			float balance = getBalance() - sum_price;
			if(balance >= 0)
			{
				setBalance(balance);
				for(int i=0;i<size;i++)
				{
					System.out.println(u.get(i).getRfid());
					pstmt.setString(1,u.get(i).getRfid());
					ResultSet rs = pstmt.executeQuery();
					if(rs.next())
					{
						Fcode = rs.getString("Fcode");
						code = rs.getString("code");
						name = rs.getString("name");
						spec = rs.getString("spec");
						price = rs.getString("price");
						img = rs.getString("img");  
						SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");  
						SimpleDateFormat df = new SimpleDateFormat("yyyyMMddHHmmss"); 
						date_s = dateFormat.format(date);
						order = df.format(date);
						System.out.println("order:"+order);
						add(Fcode,code, name, spec, price, date_s, img, order);
						setState(u.get(i).getRfid());
					}
				}
				return true;
			}
			else 
				return false;
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			DBUtils.close(conn);
		}
		return false;
	}
	
	@Override
	public void add(String Fcode,String code, String name,String spec,String price,String date,String img,String order) {
		String sql = "insert into Userdata(code,name,spec,price,date,img,orderCode,Fcode)values(?,?,?,?,?,?,?,?)";
		Connection conn =  DBUtils.open();
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, code);
			pstmt.setString(2, name);
			pstmt.setString(3, spec);
			pstmt.setString(4, price);
			pstmt.setString(5, date);
			pstmt.setString(6, img);
			pstmt.setString(7, order);
			pstmt.setString(8, Fcode);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			DBUtils.close(conn);
		}
	}

	@Override
	public JSONArray getGoodsByTCode(String TCode) {
		String sql = "select * from information where TCode='" + TCode + "'";
		Connection conn = DBUtils.open();
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery(sql);
			ResultSetMetaData md = rs.getMetaData();
			JSONArray jsonArray = new JSONArray();
			while(rs.next())
			{		
				JSONObject eventsObject = new JSONObject();
				eventsObject.put("name",rs.getString("name"));
				eventsObject.put("shelves",rs.getString("shelves"));
				eventsObject.put("spec",rs.getString("spec"));
				eventsObject.put("img",rs.getString("img"));
				eventsObject.put("findate",rs.getString("findate"));
				eventsObject.put("price",rs.getString("price"));
				eventsObject.put("spec",rs.getString("spec"));
				eventsObject.put("inventory",rs.getString("inventory"));
				jsonArray.add(eventsObject);
			}
			return jsonArray;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtils.close(conn);
		}
		return null;
	}
	
	

	@Override
	public JSONArray getGoodsByRfid(String rfid) {
		String sql = "select * from inventory where rfid = '" + rfid + "'";
		Connection conn = DBUtils.open();
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery(sql);
			ResultSetMetaData md = rs.getMetaData();
			JSONArray jsonArray = new JSONArray();
			while(rs.next())
			{		
				JSONObject eventsObject = new JSONObject();
				eventsObject.put("name",rs.getString("name"));
				eventsObject.put("shelves",rs.getString("shelves"));
				eventsObject.put("spec",rs.getString("spec"));
				eventsObject.put("img",rs.getString("img"));
				eventsObject.put("findate",rs.getString("findate"));
				eventsObject.put("price",rs.getString("price"));
				eventsObject.put("spec",rs.getString("spec"));
				eventsObject.put("state",rs.getString("state"));
				eventsObject.put("rfid", rfid);
				jsonArray.add(eventsObject);
			}
			return jsonArray;
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBUtils.close(conn);
		}
		return null;
	}
	
	public float getBalance() {
		Connection conn = DBUtils.open();
		String sql = "select balance from user";
		try {
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			if(rs.next())
			{
				float balance = rs.getInt("balance");
				return balance;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			DBUtils.close(conn);
		}
		return -1;
	}

	@Override
	public boolean setBalance(float balance) {
		System.out.println("balance : " + balance + "元");
		Connection conn = DBUtils.open();
		String sql = "update user set balance = '" + balance + "'";
		try {
			Statement stmt = conn.createStatement();
			stmt.executeUpdate(sql);
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}finally{
			DBUtils.close(conn);
		}		
	}
	
	@Override
	public boolean matchusernameandpassword(String username,String password){
		Connection conn = DBUtils.open();
		String sql = "select * from user where account = '"+ username + "' and password = '" + password + "'";
		try{
			PreparedStatement pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery(sql);
			while(rs.next()){
				return true;
			}
		}catch (SQLException e){
			e.printStackTrace();
		}finally{
			DBUtils.close(conn);
		}
		return false;
	}

	@Override
	public int getInventoryByTCode(String TCode) {
		String sql = "select count(*) from inventory where TCode = '" + TCode + "'";
		//String sql = "select sum(case when TCode= '" + TCode + "' then 1 else 0 end) as a1 from inventory";
		int inventory = 0;
		Connection conn = DBUtils.open();
		try {
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			if(rs.next())
				inventory = rs.getInt(1);
			return inventory;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtils.close(conn);
		}
		return 0;
	}

	@Override
	public int getInventoryByname(String name) {
		String sql = "select count(*) from inventory where name = '" + name + "'";
		//String sql = "select sum(case when TCode= '" + TCode + "' then 1 else 0 end) as a1 from inventory";
		int inventory = 0;
		Connection conn = DBUtils.open();
		try {
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			if(rs.next())
				inventory = rs.getInt(1);
			return inventory;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtils.close(conn);
		}
		return 0;
	}

	@Override
	public void setInventory(String name) {
		int inventory = getInventoryByname(name);
		System.out.println(name+inventory);
		String sql = "update information set inventory =" + inventory + " where name ='" + name + "'";
		System.out.println(sql);
		Connection conn = DBUtils.open();
		try {
			Statement stmt = conn.createStatement();
			stmt.executeUpdate(sql);
		} catch (SQLException e) {	
			e.printStackTrace();
		}finally {
			DBUtils.close(conn);
		}
	}

	@Override
	public JSONArray getAllKind() {
		Connection conn = DBUtils.open();
		JSONArray jsonArray = new JSONArray();
		String[] res = getFkind();
		String sql = "select name from skind where Fkind = ?";
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			for(int i=0;i<res.length;i++)
			{
				pstmt.setString(1, res[i]);
				String name[] = new String[getColumn(res[i])];
				ResultSet rs = pstmt.executeQuery();
				rs.next();
				for(int j=0;j<name.length;j++,rs.next())
				{
					name[j] = rs.getString("name");
				}
				JSONObject eventsObject = new JSONObject();
				eventsObject.put(res[i],name);
				jsonArray.add(eventsObject);
			}
			return jsonArray;
		} catch (SQLException e1) {
			e1.printStackTrace();
		}finally {
			DBUtils.close(conn);
		}
		return null;
	}

	@Override
	public int getColumn(String Fkind) {
		String sql = "select count(*) from skind where Fkind = '" + Fkind + "'";
		Connection conn = DBUtils.open();
		int column = 0;
		try {
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			if(rs.next())
			{
				column = Integer.parseInt(rs.getString("count(*)"));
			}
			return column;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtils.close(conn);
		}
		
		return column;
	}

	@Override
	public String[] getFkind() {
		String sql = "select distinct Fkind from skind";
		Connection conn = DBUtils.open();
		try {
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			rs.last();
			int lenth = rs.getRow();
			System.out.println("lenth = " + lenth);
			String[] res = new String[lenth];
			rs.first();
			for(int i=0;i<lenth;i++,rs.next())
			{
				res[i] = rs.getString("Fkind");
			}
			return res;
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBUtils.close(conn);
		}
		return null;
	}

	@Override
	public String[] getDiscount() {
		String sql = "select name from discount";
		Connection conn = DBUtils.open();
		int i = 0;
		try {
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			rs.last();
			int lenth = rs.getRow();
			rs.beforeFirst();
			String[] name = new String[lenth];
			while(rs.next())
			{
				name[i] = rs.getString("name");
				i++;
			}
			return name;
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBUtils.close(conn);
		}
		return null;
	}

	@Override
	public JSONArray getGoodsByname(String name) {
		String sql = "select * from information where name='"+ name +"'";
		Connection conn = DBUtils.open();
		Goods g = new Goods();
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery(sql);
			ResultSetMetaData md = rs.getMetaData();
			JSONArray jsonArray = new JSONArray();
			if(rs.next())
			{
				JSONObject eventsObject = new JSONObject();
				eventsObject.put("name",rs.getString("name"));
				eventsObject.put("shelves",rs.getString("shelves"));
				eventsObject.put("spec",rs.getString("spec"));
				eventsObject.put("img",rs.getString("img"));
				eventsObject.put("findate",rs.getString("findate"));
				eventsObject.put("price",rs.getString("price"));
				eventsObject.put("spec",rs.getString("spec"));
				eventsObject.put("inventory",rs.getString("inventory"));
				jsonArray.add(eventsObject);
			}
			return jsonArray;
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBUtils.close(conn);
		}
		return null;
	}

	@Override
	public JSONArray getGoodsBykind(String kind) {
		String sql = "select * from information where kind='"+ kind +"'";
		Connection conn = DBUtils.open();
		Goods g = new Goods();
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery(sql);
			ResultSetMetaData md = rs.getMetaData();
			JSONArray jsonArray = new JSONArray();
			while(rs.next())
			{
				JSONObject eventsObject = new JSONObject();
				eventsObject.put("name",rs.getString("name"));
				eventsObject.put("shelves",rs.getString("shelves"));
				eventsObject.put("spec",rs.getString("spec"));
				eventsObject.put("img",rs.getString("img"));
				eventsObject.put("findate",rs.getString("findate"));
				eventsObject.put("price",rs.getString("price"));
				eventsObject.put("inventory",rs.getString("inventory"));
				jsonArray.add(eventsObject);
			}
			return jsonArray;
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBUtils.close(conn);
		}
		return null;
	}

	@Override
	public JSONObject getRecord() {
		String sql = "select * from userdata";
		Connection conn = DBUtils.open();
		try {
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			JSONObject jsonObject = new JSONObject(new LinkedHashMap());
			int i =1;
			while(rs.next())
			{
				System.out.println("No.:"+i);
				JSONArray jsonArray = new JSONArray();
				JSONObject eventsObject = new JSONObject(new LinkedHashMap());
				eventsObject.put("name",rs.getString("name"));
				eventsObject.put("spec",rs.getString("spec"));
				eventsObject.put("img",rs.getString("img"));
				eventsObject.put("date",rs.getString("date"));
				eventsObject.put("price",rs.getString("price"));
				jsonArray.add(eventsObject);
				System.out.println(jsonArray);
				jsonObject.put(i+"", jsonArray);
				i++;	
			}
			System.out.println(jsonObject);
			return jsonObject;
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBUtils.close(conn);
		}
		return null;
	}

	@Override
	public JSONArray getUserdata(String account) {
		String sql = "select * from user where account = '" + account + "'";
		Connection conn = DBUtils.open();
		try {
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			JSONArray jsonArray = new JSONArray();
			if(rs.next())
			{
				JSONObject eventsObject = new JSONObject();
				eventsObject.put("account",rs.getString("account"));
				eventsObject.put("balance",rs.getString("balance"));
				eventsObject.put("vallet",rs.getString("vallet"));
				eventsObject.put("coin",rs.getString("coin"));
				eventsObject.put("VIP",rs.getString("VIP"));
				jsonArray.add(eventsObject);
			}
			return jsonArray;
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBUtils.close(conn);
		}
		return null;
	}

	@Override
	public boolean register(String username, String password) {
		String sql = "insert into user(username.password,balance,vallet,coin,VIP)values('"+ username + "','" + password + "','0','0','0','0'";
		Connection conn = DBUtils.open();
		try {
			Statement stmt = conn.createStatement();
			stmt.execute(sql);
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBUtils.close(conn);
		}
		return false;
	}

	@Override
	public String[] getOrderCode() {
		String sql = "select distinct orderCode from userdata";
		Connection conn = DBUtils.open();
		try {
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			rs.last();
			int lenth = rs.getRow();
			System.out.println("lenth = " + lenth);
			String[] res = new String[lenth];
			rs.first();
			for(int i=0;i<lenth;i++,rs.next())
			{
				res[i] = rs.getString("orderCode");
			}
			return res;
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBUtils.close(conn);
		}
		return null;
	}

	@Override
	public JSONObject getAllOrder() {
		Connection conn = DBUtils.open();
		String[] res = getOrderCode();
		String sql = "select * from userdata where orderCode = ?";
		JSONObject jsonObject = new JSONObject(new LinkedHashMap());
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			for(int i=0;i<res.length;i++)
			{
				JSONArray jsonArray = new JSONArray();
				pstmt.setString(1, res[i]);
				int length = getOrderColumn(res[i]);
//				String name[] = new String[getOrderColumn(res[i])];
				ResultSet rs = pstmt.executeQuery();
				rs.next();
				for(int j=0;j<length;j++,rs.next())
				{
					System.out.println("No.:"+i);
					JSONObject eventsObject = new JSONObject(new LinkedHashMap());
					eventsObject.put("name",rs.getString("name"));
					eventsObject.put("spec",rs.getString("spec"));
					eventsObject.put("img",rs.getString("img"));
					eventsObject.put("date",rs.getString("date"));
					eventsObject.put("price",rs.getString("price"));
					eventsObject.put("order",rs.getString("orderCode"));
					eventsObject.put("number","1");
					jsonArray.add(eventsObject);
				}
				jsonObject.put(i+"", jsonArray);
				System.out.println(jsonObject);
			}
			return jsonObject;
		} catch (SQLException e1) {
			e1.printStackTrace();
		}finally {
			DBUtils.close(conn);
		}
		return null;
	}

	@Override
	public int getOrderColumn(String orderCode) {
		String sql = "select count(*) from userdata where orderCode = '" + orderCode + "'";
		Connection conn = DBUtils.open();
		int column = 0;
		try {
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			if(rs.next())
			{
				column = Integer.parseInt(rs.getString("count(*)"));
			}
			return column;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtils.close(conn);
		}
		
		return column;
	}

	@Override
	public boolean setState(String rfid) {
		String sql = "update inventory set state = '1' where rfid = '" + rfid + "'";
		Connection conn = DBUtils.open();
		try {
			Statement stmt = conn.createStatement();
			stmt.execute(sql);
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBUtils.close(conn);
		}		
		return false;
	}

	@Override
	public boolean charge(String money) {
		float balance = getBalance();
		float charge = Float.valueOf(money);
		System.out.println("Charge:" + charge);
		balance += charge;
		return setBalance(balance);
	}

	
}