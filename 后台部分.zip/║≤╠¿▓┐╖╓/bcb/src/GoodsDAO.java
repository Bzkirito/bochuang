import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import com.alibaba.fastjson.*;

public interface GoodsDAO {
	public void add(String Fcode,String code, String name,String spec,String price,String date,String img,String order);  //增加用户商品购买记录
	public boolean get(List<User> u);   //获取用户购买商品信息，并判断用户余额是否充足，最后调用add增加用户商品购买记录
	public JSONArray getGoodsByid(String id);  //根据商品id获取商品信息
	public JSONArray getGoodsByCode(String code);  //根据商品Code获取商品信息
	public JSONArray getGoodsByTCode(String Tcode);  //根据商品条形码获取商品信息
	public JSONArray getGoodsByRfid(String rfid);  //根据商品Rfid获取商品信息
	public JSONArray getGoodsByname(String name);  //根据商品name获取商品信息
	public JSONArray getGoodsBykind(String kind);  //根据商品kind获取商品信息
	public boolean setBalance(float balance);  //修改用户余额（购买商品后）
	public float getBalance();  //获取用户余额
	public boolean matchusernameandpassword(String username,String password);  //根据帐号密码进行登录
	public int getInventoryByTCode(String TCode); //根据商品条形码获取商品库存
	public int getInventoryByname(String name);  //根据商品名获取商品库存
	public void setInventory(String name);
	public JSONArray getAllKind(); //获取全部种类
	public String[] getFkind();	//获取一级种类
	public int getColumn(String Fkind);		//获取种类数
	public String[] getDiscount();	//获取优惠商品名
	public JSONObject getRecord();	//获取用户购买记录
	public JSONArray getUserdata(String account);	//获取用户信息	
	public boolean register(String username,String password);	//注册
	public String[] getOrderCode();	//获取订单号
	public JSONObject getAllOrder(); //获取所有订单
	public int getOrderColumn(String orderCode);	//获取订单数
	public boolean setState(String rfid); 	//修改购买状态
	public boolean charge(String money);	//氪金
}
