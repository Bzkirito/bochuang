﻿namespace DBMan
{
    partial class DBM
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DBM));
            this.addBtn = new System.Windows.Forms.Button();
            this.delBtn = new System.Windows.Forms.Button();
            this.upBtn = new System.Windows.Forms.Button();
            this.traBtn = new System.Windows.Forms.Button();
            this.kindBtn = new System.Windows.Forms.Button();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.Discount = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.state = new System.Windows.Forms.Label();
            this.CloseMonitor = new System.Windows.Forms.Button();
            this.OpenMonitor = new System.Windows.Forms.Button();
            this.BoundRate = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.comCom = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // addBtn
            // 
            this.addBtn.Location = new System.Drawing.Point(103, 32);
            this.addBtn.Name = "addBtn";
            this.addBtn.Size = new System.Drawing.Size(75, 23);
            this.addBtn.TabIndex = 0;
            this.addBtn.Text = "增加商品";
            this.addBtn.UseVisualStyleBackColor = true;
            this.addBtn.Click += new System.EventHandler(this.addBtn_Click);
            // 
            // delBtn
            // 
            this.delBtn.Location = new System.Drawing.Point(11, 86);
            this.delBtn.Name = "delBtn";
            this.delBtn.Size = new System.Drawing.Size(75, 23);
            this.delBtn.TabIndex = 1;
            this.delBtn.Text = "删除商品";
            this.delBtn.UseVisualStyleBackColor = true;
            this.delBtn.Click += new System.EventHandler(this.delBtn_Click);
            // 
            // upBtn
            // 
            this.upBtn.Location = new System.Drawing.Point(103, 86);
            this.upBtn.Name = "upBtn";
            this.upBtn.Size = new System.Drawing.Size(75, 23);
            this.upBtn.TabIndex = 2;
            this.upBtn.Text = "修改商品";
            this.upBtn.UseVisualStyleBackColor = true;
            this.upBtn.Click += new System.EventHandler(this.upBtn_Click);
            // 
            // traBtn
            // 
            this.traBtn.Location = new System.Drawing.Point(11, 32);
            this.traBtn.Name = "traBtn";
            this.traBtn.Size = new System.Drawing.Size(75, 23);
            this.traBtn.TabIndex = 3;
            this.traBtn.Text = "商品总览";
            this.traBtn.UseVisualStyleBackColor = true;
            this.traBtn.Click += new System.EventHandler(this.traBtn_Click);
            // 
            // kindBtn
            // 
            this.kindBtn.Location = new System.Drawing.Point(66, 33);
            this.kindBtn.Name = "kindBtn";
            this.kindBtn.Size = new System.Drawing.Size(75, 23);
            this.kindBtn.TabIndex = 4;
            this.kindBtn.Text = "增加种类";
            this.kindBtn.UseVisualStyleBackColor = true;
            this.kindBtn.Click += new System.EventHandler(this.kindBtn_Click);
            // 
            // serialPort1
            // 
            this.serialPort1.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.serialPort1_DataReceived);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.addBtn);
            this.groupBox1.Controls.Add(this.upBtn);
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Controls.Add(this.traBtn);
            this.groupBox1.Controls.Add(this.delBtn);
            this.groupBox1.Location = new System.Drawing.Point(24, 22);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(204, 273);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "基础功能区";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.Discount);
            this.groupBox2.Controls.Add(this.kindBtn);
            this.groupBox2.Location = new System.Drawing.Point(0, 151);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(204, 122);
            this.groupBox2.TabIndex = 6;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "扩展功能区";
            // 
            // Discount
            // 
            this.Discount.Location = new System.Drawing.Point(66, 82);
            this.Discount.Name = "Discount";
            this.Discount.Size = new System.Drawing.Size(75, 23);
            this.Discount.TabIndex = 5;
            this.Discount.Text = "优惠商品";
            this.Discount.UseVisualStyleBackColor = true;
            this.Discount.Click += new System.EventHandler(this.Discount_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.state);
            this.groupBox3.Controls.Add(this.CloseMonitor);
            this.groupBox3.Controls.Add(this.OpenMonitor);
            this.groupBox3.Controls.Add(this.BoundRate);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.comCom);
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Location = new System.Drawing.Point(295, 30);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(200, 265);
            this.groupBox3.TabIndex = 7;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "监控区设置";
            // 
            // state
            // 
            this.state.AutoSize = true;
            this.state.Location = new System.Drawing.Point(12, 246);
            this.state.Name = "state";
            this.state.Size = new System.Drawing.Size(65, 12);
            this.state.TabIndex = 6;
            this.state.Text = "监控已关闭";
            // 
            // CloseMonitor
            // 
            this.CloseMonitor.Location = new System.Drawing.Point(35, 194);
            this.CloseMonitor.Name = "CloseMonitor";
            this.CloseMonitor.Size = new System.Drawing.Size(148, 23);
            this.CloseMonitor.TabIndex = 5;
            this.CloseMonitor.Text = "关闭监控";
            this.CloseMonitor.UseVisualStyleBackColor = true;
            this.CloseMonitor.Click += new System.EventHandler(this.CloseMonitor_Click);
            // 
            // OpenMonitor
            // 
            this.OpenMonitor.Location = new System.Drawing.Point(35, 143);
            this.OpenMonitor.Name = "OpenMonitor";
            this.OpenMonitor.Size = new System.Drawing.Size(148, 23);
            this.OpenMonitor.TabIndex = 4;
            this.OpenMonitor.Text = "开启监控";
            this.OpenMonitor.UseVisualStyleBackColor = true;
            this.OpenMonitor.Click += new System.EventHandler(this.OpenMonitor_Click);
            // 
            // BoundRate
            // 
            this.BoundRate.FormattingEnabled = true;
            this.BoundRate.Items.AddRange(new object[] {
            "115200",
            "9600"});
            this.BoundRate.Location = new System.Drawing.Point(79, 83);
            this.BoundRate.Name = "BoundRate";
            this.BoundRate.Size = new System.Drawing.Size(104, 20);
            this.BoundRate.TabIndex = 3;
            this.BoundRate.Text = "115200";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 86);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 2;
            this.label2.Text = "波特率：";
            // 
            // comCom
            // 
            this.comCom.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comCom.FormattingEnabled = true;
            this.comCom.Location = new System.Drawing.Point(79, 32);
            this.comCom.Name = "comCom";
            this.comCom.Size = new System.Drawing.Size(104, 20);
            this.comCom.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "串口设置：";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(454, 317);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 12);
            this.label3.TabIndex = 8;
            this.label3.Text = "v. 2.8";
            // 
            // DBM
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(526, 338);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox1);
            this.HelpButton = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "DBM";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "商品后台管理";
            this.Load += new System.EventHandler(this.DBM_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button addBtn;
        private System.Windows.Forms.Button delBtn;
        private System.Windows.Forms.Button upBtn;
        private System.Windows.Forms.Button traBtn;
        private System.Windows.Forms.Button kindBtn;
        private System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button Discount;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label state;
        private System.Windows.Forms.Button CloseMonitor;
        private System.Windows.Forms.Button OpenMonitor;
        private System.Windows.Forms.ComboBox BoundRate;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comCom;
        private System.Windows.Forms.Label label3;
    }
}

