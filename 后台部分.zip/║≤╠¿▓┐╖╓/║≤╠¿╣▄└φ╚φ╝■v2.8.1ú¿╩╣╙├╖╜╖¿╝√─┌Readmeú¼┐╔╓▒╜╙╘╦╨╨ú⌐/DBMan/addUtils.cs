﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace DBMan
{
    class addUtils
    {
        public MySqlDataReader getInformation(String TCode)
        {
            Console.WriteLine(TCode);
            String sql = "select * from information where TCode = '" + TCode + "'";
            MySqlConnection conn = DBUtils.open();
            MySqlCommand cmd = new MySqlCommand(sql, conn);
            try
            {
                MySqlDataReader rs = cmd.ExecuteReader();
                return rs;
            }
            catch (MySqlException ex)
            {
                Console.WriteLine(ex.Message);
            }
            return null;
        }
    }
}