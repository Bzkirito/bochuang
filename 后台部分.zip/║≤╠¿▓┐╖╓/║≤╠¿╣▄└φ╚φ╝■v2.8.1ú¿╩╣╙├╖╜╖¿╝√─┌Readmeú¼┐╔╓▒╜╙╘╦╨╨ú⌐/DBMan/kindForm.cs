﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBMan
{
    public partial class kindForm : Form
    {
        public static kindForm ks;
        DAOInterface qk = new sqlDAO();
        public kindForm()
        {
            InitializeComponent();
            ks = this;
        }

        private void kindForm_Load(object sender, EventArgs e)
        {
           qk.querryKind();
        }


        /*private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                String name = dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString();
                kindDel.Text = name;
            }
            catch(Exception ex)
            {
            }
        }*/

        private void delKindBtn_Click(object sender, EventArgs e)
        {
            DAOInterface dk = new sqlDAO();
            dk.deleteKind(kindDel.Text.ToString());
            qk.querryKind();
        }

        private void addKindBtn_Click(object sender, EventArgs e)
        {
            DAOInterface ak = new sqlDAO();
            String state = ak.addKind(addKind.Text.ToString());
            if (state == "true")
            {
                MessageBox.Show("添加成功");
                addKind.Text = "";
            }
            else
                MessageBox.Show("添加失败，存在同名种类");
            qk.querryKind();
        }

        private void dataGridView1_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            try
            {
                String kindName = dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString();
                SkindForm sf = new SkindForm(kindName);
                sf.ShowDialog();
            }
            catch (Exception ex)
            {
            }
        }

        private void dataGridView1_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            try
            {
                String name = dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString();
                kindDel.Text = name;
            }
            catch (Exception ex)
            {
            }
        }
    }
}