﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace DBMan
{
    static class Program
    {
        /// <summary>
        /// 应用程序的主入口点。
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            //Application.Run(new DBM());
            Mutex mutex = new Mutex(false, "ThisShouldOnlyRunOnce");
            bool Running = !mutex.WaitOne(0, false);
            if (!Running)
            {
                login lf = new login();
                if(lf.ShowDialog() == DialogResult.OK)
                    Application.Run(new DBM());
            }
        }
    }
}
