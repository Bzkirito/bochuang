﻿namespace DBMan
{
    partial class SkindForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.delKindBtn = new System.Windows.Forms.Button();
            this.SkindDel = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.addSkindBtn = new System.Windows.Forms.Button();
            this.addSkind = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Skind = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.delKindBtn);
            this.groupBox2.Controls.Add(this.SkindDel);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Location = new System.Drawing.Point(253, 188);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(226, 147);
            this.groupBox2.TabIndex = 7;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "种类删除";
            // 
            // delKindBtn
            // 
            this.delKindBtn.Location = new System.Drawing.Point(66, 101);
            this.delKindBtn.Name = "delKindBtn";
            this.delKindBtn.Size = new System.Drawing.Size(75, 23);
            this.delKindBtn.TabIndex = 6;
            this.delKindBtn.Text = "删除";
            this.delKindBtn.UseVisualStyleBackColor = true;
            this.delKindBtn.Click += new System.EventHandler(this.delKindBtn_Click);
            // 
            // SkindDel
            // 
            this.SkindDel.Location = new System.Drawing.Point(104, 37);
            this.SkindDel.Name = "SkindDel";
            this.SkindDel.Size = new System.Drawing.Size(100, 21);
            this.SkindDel.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 40);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 12);
            this.label2.TabIndex = 2;
            this.label2.Text = "种类名称 ：";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.addSkindBtn);
            this.groupBox1.Controls.Add(this.addSkind);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(253, 22);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(226, 147);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "添加种类";
            // 
            // addSkindBtn
            // 
            this.addSkindBtn.Location = new System.Drawing.Point(66, 98);
            this.addSkindBtn.Name = "addSkindBtn";
            this.addSkindBtn.Size = new System.Drawing.Size(75, 23);
            this.addSkindBtn.TabIndex = 5;
            this.addSkindBtn.Text = "添加";
            this.addSkindBtn.UseVisualStyleBackColor = true;
            this.addSkindBtn.Click += new System.EventHandler(this.addSkindBtn_Click);
            // 
            // addSkind
            // 
            this.addSkind.Location = new System.Drawing.Point(104, 34);
            this.addSkind.Name = "addSkind";
            this.addSkind.Size = new System.Drawing.Size(100, 21);
            this.addSkind.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "种类名称 ：";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Skind});
            this.dataGridView1.Location = new System.Drawing.Point(32, 22);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.Size = new System.Drawing.Size(145, 313);
            this.dataGridView1.TabIndex = 5;
            this.dataGridView1.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridView1_CellMouseClick);
            // 
            // Skind
            // 
            this.Skind.HeaderText = "Skind";
            this.Skind.Name = "Skind";
            this.Skind.ReadOnly = true;
            // 
            // SkindForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(512, 363);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.dataGridView1);
            this.Name = "SkindForm";
            this.Text = "Skind";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.SkindForm_FormClosed);
            this.Load += new System.EventHandler(this.SkindForm_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button delKindBtn;
        private System.Windows.Forms.TextBox SkindDel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button addSkindBtn;
        private System.Windows.Forms.TextBox addSkind;
        private System.Windows.Forms.Label label1;
        public System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Skind;
    }
}