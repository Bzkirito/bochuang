﻿namespace DBMan
{
    partial class querryForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.dataID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataSpec = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.price = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataState = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataID,
            this.dataCode,
            this.dataName,
            this.dataSpec,
            this.price,
            this.dataDate,
            this.dataState});
            this.dataGridView1.Location = new System.Drawing.Point(3, 3);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.Size = new System.Drawing.Size(743, 380);
            this.dataGridView1.TabIndex = 0;
            // 
            // dataID
            // 
            this.dataID.HeaderText = "商品ID";
            this.dataID.Name = "dataID";
            this.dataID.ReadOnly = true;
            // 
            // dataCode
            // 
            this.dataCode.HeaderText = "商品编码";
            this.dataCode.Name = "dataCode";
            this.dataCode.ReadOnly = true;
            // 
            // dataName
            // 
            this.dataName.HeaderText = "商品名称";
            this.dataName.Name = "dataName";
            this.dataName.ReadOnly = true;
            // 
            // dataSpec
            // 
            this.dataSpec.HeaderText = "规格";
            this.dataSpec.Name = "dataSpec";
            this.dataSpec.ReadOnly = true;
            // 
            // price
            // 
            this.price.HeaderText = "价格";
            this.price.Name = "price";
            this.price.ReadOnly = true;
            // 
            // dataDate
            // 
            this.dataDate.HeaderText = "添加日期";
            this.dataDate.Name = "dataDate";
            this.dataDate.ReadOnly = true;
            // 
            // dataState
            // 
            this.dataState.HeaderText = "是否支付";
            this.dataState.Name = "dataState";
            this.dataState.ReadOnly = true;
            // 
            // querryForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(749, 395);
            this.Controls.Add(this.dataGridView1);
            this.Location = new System.Drawing.Point(1050, 600);
            this.Name = "querryForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "querryForm";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        public System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataID;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataName;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataSpec;
        private System.Windows.Forms.DataGridViewTextBoxColumn price;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataState;
    }
}