﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Net;
using System.Threading;
using System.IO.Ports;

namespace DBMan
{
    public partial class addForm : Form
    {
        private readonly object _tasklock = new object();
        private bool _locking = false;
        private volatile bool _contloop = true;
/***************************************线程************************************************/
        Byte[] InputBuf = new Byte[128];
        String img = "http://localhost/k.jpg";
        public static addForm af;
        public Boolean auto = true;
        public addForm()
        {
            InitializeComponent();
            CheckForIllegalCrossThreadCalls = false;
            af = this;
            try
            {
                Image O_Image = Image.FromStream(WebRequest.Create("http://localhost/kk.jpg").GetResponse().GetResponseStream());
                pictureBox1.Image = O_Image;
            }
            catch(System.Net.WebException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void addBtn_Click(object sender, EventArgs e)
        {
            sqlDAO add = new sqlDAO();

            if (addImg.Text.ToString() != "NULL")
            {
                img = "http://localhost/kk.jpg";
                img = addImg.Text.ToString();
            }

            if (addCode.Text.ToString() == "" || addName.Text.ToString() == "" || addSpec.Text.ToString() == "" || addPri.Text.ToString() == "" || addShl.Text.ToString() == "" || addFin.Text.ToString() == "")
            {
                MessageBox.Show("请填写完整的商品信息");
                Image O_Image = Image.FromStream(WebRequest.Create("http://localhost/k.jpg").GetResponse().GetResponseStream());
                pictureBox1.Image = O_Image;
                return;
            }

            if (add.checkAdd(addRfid.Text))
            {
                MessageBox.Show("此商品已存在");
                return;
            }
            else
            {
                String Fcode = "";
                MySqlConnection conn = DBUtils.open();
                String sql = "select Fcode from information where name = '" + addName.Text + "'";
                try
                {
                    MySqlCommand cmd = new MySqlCommand(sql, conn);
                    MySqlDataReader dr = cmd.ExecuteReader();
                    if (dr.Read())
                    {
                        Fcode = dr.GetString("Fcode");
                    }
                    else
                    {
                        MessageBox.Show("未知错误");
                        return;
                    }
                }
                catch
                {
                }
                finally
                {
                    conn.Close();
                }
                String rs = add.add(Fcode,addCode.Text.ToString(), addName.Text.ToString(), addSpec.Text.ToString(),
                    addPri.Text.ToString(), addShl.Text.ToString(), addFin.Text.ToString(), img,addRfid.Text.ToString());
                if (rs == "true")
                {
                    MessageBox.Show("添加成功");
                }
                else
                {
                    MessageBox.Show(rs);
                }
            }
        }

        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            Thread.Sleep(12);
            string str = "";
            do
            {
                int count = serialPort1.BytesToRead;
                Console.WriteLine(count);
                if (count <= 0)
                    break;
                char[] readBuffer = new char[count];
                Application.DoEvents();
                serialPort1.Read(readBuffer, 0, count);
                for(int i =0;i<readBuffer.Length;i++)
                    str += readBuffer[i];
            } while (serialPort1.BytesToRead > 0);
            string[] strArray = str.Split(new string[] { "+" }, StringSplitOptions.RemoveEmptyEntries);
            string rfid = strArray[0];
            if (rfid.Substring(0, 1) != "4")
            {
                MessageBox.Show("接收到的rfid值有误，请重新传输");
                return;
            }
            try
            {
                string qrcode = strArray[1];
                qrcode = qrcode.Replace("\r", "");
                qrcode = qrcode.Replace("\n", "");
                qrcode = qrcode.Replace(" ", "");
                if (qrcode == "" || rfid == "")
                {
                    MessageBox.Show("传入的值为空,请检查扫描装置");
                    return;
                }
                Console.WriteLine("qrcode = " + qrcode);
                Console.WriteLine("rfid = " + rfid);
                addUtils au = new addUtils();
                addRfid.Text = rfid;
                MySqlDataReader rs = au.getInformation(qrcode);
                getData(rs);
                if (auto)
                {
                    autoAdd();
                }
            }
            catch
            {
                Image O_Image = Image.FromStream(WebRequest.Create("http://localhost/k.jpg").GetResponse().GetResponseStream());
                pictureBox1.Image = O_Image;
                MessageBox.Show("数据接收异常，请重新扫描");
            }
        }

/*        private void serialPort2_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            Thread.Sleep(12);
            string str = "";
            do
            {
                int count = serialPort2.BytesToRead;
                if (count <= 0)
                    break;
                byte[] readBuffer = new byte[count];
                Application.DoEvents();
                for (int i = 0; i < readBuffer.Length; i++)
                {
                    str += Convert.ToString(readBuffer[i], 10);
                }
            } while (serialPort2.BytesToRead > 0);
            //MessageBox.Show(str);
            str = str.Replace("\r", "");
            Console.WriteLine(str);
        }
*/
        private void getData(MySqlDataReader rs)
        {
            if (rs.Read())
            {
                Console.WriteLine("inread");
                img = addImg.Text = rs.GetString("img");
                addName.Text = rs.GetString("name");
                addCode.Text = rs.GetString("code");
                addSpec.Text = rs.GetString("spec");
                addShl.Text = rs.GetString("shelves");
                addPri.Text = rs.GetString("price");
                addFin.Text = rs.GetString("findate");
                try
                {
                    Image O_Image = Image.FromStream(WebRequest.Create(img).GetResponse().GetResponseStream());
                    //Image O_Image = Image.FromStream(WebRequest.Create(img).GetResponse().GetResponseStream());
                    pictureBox1.Image = O_Image;
                    //Console.WriteLine(addImg.Text);
                }
                catch (ArgumentException ex)
                {
                    Image O_Image = Image.FromStream(WebRequest.Create("http://localhost/k.jpg").GetResponse().GetResponseStream());
                    pictureBox1.Image = O_Image;
                    MessageBox.Show(ex.Message);
                }

            }
        }

        private void addForm_Load(object sender, EventArgs e)
        {
            string[] PortNames = SerialPort.GetPortNames();
            for(int i=0;i<PortNames.Length;i++)
            {
                QRCombo.Items.Add(PortNames[i]);
            }
        }


        private void QRCombo_SelectedIndexChanged(object sender, EventArgs e)
        {
            /*serialPort1.Close();
            serialPort1.PortName = QRCombo.Text;
            serialPort1.BaudRate = int.Parse(BoundRate.Text);
                try
                {
                    serialPort1.Open();
                }
                catch (System.UnauthorizedAccessException ex)
                {
                    DialogResult dr;
                    dr = MessageBox.Show("串口被占用", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                catch (System.IO.IOException)
                {
                    DialogResult dr;
                    dr = MessageBox.Show("串口不存在", "提示", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }*/
        }

        private void addPortClose_Click(object sender, EventArgs e)
        {
            serialPort1.Close();
            currentPort.Text = "NULL";
        }

        private void addPortOpen_Click(object sender, EventArgs e)
        {
            serialPort1.Close();
            if (QRCombo.Text == "" || BoundRate.Text == "")
                return;
            serialPort1.PortName = QRCombo.Text;
            serialPort1.BaudRate = int.Parse(BoundRate.Text);
            try
            {
                serialPort1.Open();
                currentPort.Text = QRCombo.Text + "(In Working)";
            }
            catch (System.UnauthorizedAccessException ex)
            {
                DialogResult dr;
                dr = MessageBox.Show("串口被占用", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (System.IO.IOException)
            {
                DialogResult dr;
                dr = MessageBox.Show("串口不存在", "提示", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        private void addForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            serialPort1.Close();
            this.DialogResult = DialogResult.OK;
        }

        private void autoAdd()
        {
            sqlDAO add = new sqlDAO();

            if (addImg.Text.ToString() != "NULL")
            {
                img = "http://localhost/kk.jpg";
                img = addImg.Text.ToString();
            }

            if (addCode.Text.ToString() == "" || addName.Text.ToString() == "" || addSpec.Text.ToString() == "" || addPri.Text.ToString() == "" || addShl.Text.ToString() == "" || addFin.Text.ToString() == "")
            {
                MessageBox.Show("请填写完整的商品信息");
                Image O_Image = Image.FromStream(WebRequest.Create("http://localhost/k.jpg").GetResponse().GetResponseStream());
                pictureBox1.Image = O_Image;
                return;
            }

            if (add.checkAdd(addRfid.Text))
            {
                Dialog_Err dialog_err = new Dialog_Err();
                dialog_err.ShowDialog();
                return;
            }
            else
            {
                String Fcode = "";
                MySqlConnection conn = DBUtils.open();
                String sql = "select Fcode from information where name = '" + addName.Text + "'";
                try
                {
                    MySqlCommand cmd = new MySqlCommand(sql, conn);
                    MySqlDataReader dr = cmd.ExecuteReader();
                    if (dr.Read())
                    {
                        Fcode = dr.GetString("Fcode");
                    }
                    else
                    {
                        MessageBox.Show("未知错误");
                        return;
                    }
                }
                catch
                {
                }
                finally
                {
                    conn.Close();
                }
                String rs = add.add(Fcode, addCode.Text.ToString(), addName.Text.ToString(), addSpec.Text.ToString(),
                    addPri.Text.ToString(), addShl.Text.ToString(), addFin.Text.ToString(), img, addRfid.Text.ToString());
                if (rs == "true")
                {
                    Dialog dialog = new Dialog();
                    dialog.ShowDialog();
                }
                else
                {
                    MessageBox.Show(rs);
                }
            }
        }

        private void autoBtn_Click(object sender, EventArgs e)
        {
            auto = true;
            modeLable.Text = "自动模式";
        }

        private void manual_Click(object sender, EventArgs e)
        {
            auto = false;
            modeLable.Text = "手动模式";
        }
        /*private void RfidCombo_SelectedIndexChanged(object sender, EventArgs e)
        {
            serialPort2.Close();
            serialPort2.PortName = BoundRate.Text;
            serialPort2.BaudRate = 9600;
            try
            {
            serialPort2.Open();
            }
            catch (System.UnauthorizedAccessException ex)
            {
            DialogResult dr;
            dr = MessageBox.Show("串口被占用", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (System.IO.IOException)
            {
            DialogResult dr;
            dr = MessageBox.Show("串口不存在", "提示", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }*/

        /*private void addPortClose_Click(object sender, EventArgs e)
        {
            addUtils au = new addUtils();
            MySqlDataReader rs = au.getInformation("6921168509256");
            getData(rs);
        }*/
    }
}