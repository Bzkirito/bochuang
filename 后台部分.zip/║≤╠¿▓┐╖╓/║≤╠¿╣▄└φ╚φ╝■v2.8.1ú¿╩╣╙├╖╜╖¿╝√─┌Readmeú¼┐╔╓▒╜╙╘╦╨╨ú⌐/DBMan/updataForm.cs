﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace DBMan
{
    public partial class updataForm : Form
    {
        public updataForm()
        {
            InitializeComponent();
        }

        private void upBtn_Click(object sender, EventArgs e)
        {
            sqlDAO up = new sqlDAO();
            up.update(upID.Text.ToString(), upCode.Text.ToString(), upName.Text.ToString(),upSpec.Text.ToString(),upPri.Text.ToString());
        }
    }
}
