﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace DBMan
{
    public partial class querryForm : Form
    {
        public static querryForm qs;
        public querryForm()
        {
            InitializeComponent();
            qs = this;
            DataGridView();
        }
        public void DataGridView()
        {
            sqlDAO q = new sqlDAO();
            q.querryData();
        }

    }
}
