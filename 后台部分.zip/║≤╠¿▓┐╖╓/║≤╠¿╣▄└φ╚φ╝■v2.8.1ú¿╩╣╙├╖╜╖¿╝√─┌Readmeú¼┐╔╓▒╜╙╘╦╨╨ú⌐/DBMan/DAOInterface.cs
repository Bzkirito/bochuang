﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBMan
{
    interface DAOInterface
    {
        String add(String Fcode,String code, String name, String spec, String price, String shelves, String findate, String img,String rfid);  //增加商品
        Boolean addDis(String Fkind,String kind,  String name, String price);      //增加商品优惠
        Boolean checkAdd(String rfid);  //检查添加商品是否重复
        Boolean checkDis(String name);  //检查添加优惠是否重复
        String delete(String id);       //删除商品
        Boolean delDis(String name);       //删除优惠
        String update(String id,String code,String name,String spec,String price);      //修改数据
        Boolean upDpToIn(String name, String price);     //同步优惠价格至现有商品库
        Boolean upDpToIm(String name, String price);     //同步优惠价格至商品信息库
        Boolean upImToIn(String name);                   //同步原始价格至商品信息库
        Boolean upImToIm(String name);                   //同步原始价格至现有信息库
        void querryData();      //查询商品数据
        void querryDiscount();      //查询折扣商品数据
        void querryKind();      //查询商品一级种类
        String[] querryKind(String NULL);      //查询商品一级种类返回String[]
        void querrySkind(String Fname);     //查询商品子类
        String[] querrySkind(String Fkind,String NULL);      //查询商品二级种类返回String[]
        String[] querryBySkind(String Fkind, String name);   //根据商品二级种类查询商品
        Boolean querryState(String rfid);   //查询商品是否付款
        String querryPrice(String name);    //查询商品价格
        String querryOriPrice(String name);    //查询商品原始价格
        String addKind(String name);        //增加商品一级种类
        String deleteKind(String name);     //删除商品一级种类
        String addSkind(String Fkind ,String name);        //增加商品二级种类
        String deleteSkind(String Fkind,String name);    //删除商品二级级类
        Boolean checkKind(String kind);     //检查一级种类是否重复
        Boolean checkSkind(String Fkind, String name);     //检查二级种类是否重复
    }
}