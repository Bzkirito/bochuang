﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Windows.Forms;

namespace DBMan
{
    class sqlDAO : DAOInterface
    {
        String time = DateTime.Now.ToLongDateString().ToString();
        public String add(String Fcode, String code, String name, String spec, String price,String shelves,String findate,String img,String rfid)
        {
            MySqlConnection conn = DBUtils.open();
            string sql = "insert into inventory(Fcode,code,name,spec,price,shelves,findate,img,date,rfid)values('"+ Fcode + "','" + code + "','" + name + "','" + spec + "','" + price + "','" + shelves + "','" + findate + "','" + img + "','" + time + "','" + rfid + "')";
            MySqlCommand cmd = new MySqlCommand(sql, conn);
            try
            {
                cmd.ExecuteNonQuery();
                return "true";
            }
            catch (MySqlException ex)
            {
                return ex.Message; 
            }
            finally
            {
                conn.Close();
            }
        }

        public Boolean addDis(string Fkind, String kind, string name, string price)
        {
            String Fprice = querryPrice(name);
            MySqlConnection conn = DBUtils.open();
            String sql = "insert into discount(Fkind,kind,name,Fprice,price)values('" + Fkind + "','" + kind + "','" + name + "','" + Fprice + "','" + price + "')";
            MySqlCommand cmd = new MySqlCommand(sql, conn);
            try
            {
                cmd.ExecuteNonQuery();
                upDpToIm(name, price);
                upDpToIn(name, price);
                return true;
            }
            catch (MySqlException ex)
            {
                return false;
            }
            finally
            {
                conn.Close();
            }
        }

        public string addKind(string name)
        {
            Boolean state = checkKind(name);
            if (state)
            {
                MySqlConnection conn = DBUtils.open();
                string sql = "insert into kind(name)values('" + name + "')";
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                try
                {
                    cmd.ExecuteNonQuery();
                    return "true";
                }
                catch (MySqlException ex)
                {
                    return ex.Message;
                }
                finally
                {
                    conn.Close();
                }
            }
            else
                return "false";
        }

        public string addSkind(String Fkind, String name)
        {
            Boolean state = false;
            state = checkSkind(Fkind, name);
            if (state)
            {
                MySqlConnection conn = DBUtils.open();
                string sql = "insert into skind(Fkind,name)values('" + Fkind + "','" + name + "')";
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                try
                {
                    cmd.ExecuteNonQuery();
                    return "true";
                }
                catch (MySqlException ex)
                {
                    return ex.Message;
                }
                finally
                {
                    conn.Close();
                }
            }
            else
                return "false";
        }

        public bool checkAdd(string rfid)
        {
            MySqlConnection conn = DBUtils.open();
            String sql = "select * from inventory where rfid = '" + rfid + "'";
            MySqlCommand cmd = new MySqlCommand(sql, conn);
            try
            {
                MySqlDataReader rs = cmd.ExecuteReader();
                if (rs.Read())
                    return true;
                else
                    return false;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();
            }
            return true;
        }

        public bool checkDis(string name)
        {
            MySqlConnection conn = DBUtils.open();
            String sql = "select * from discount where name = '" + name + "'";
            MySqlCommand cmd = new MySqlCommand(sql, conn);
            try
            {
                MySqlDataReader rs = cmd.ExecuteReader();
                if (rs.Read())
                    return true;
                else
                    return false;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();
            }
            return true;
        }

        public Boolean checkKind(string kind)
        {
            MySqlConnection conn = DBUtils.open();
            String sql = "select name from kind where name = '" + kind + "'";
            MySqlCommand cmd = new MySqlCommand(sql, conn);
            try
            {
                MySqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    Console.WriteLine(dr.GetString("name"));
                    return false;
                }
                else
                    return true;
            }
            catch(Exception ex)
            {
                MessageBox.Show("发生了不可描述的异常: " +ex.Message);
                return false;
            }
            finally
            {
                conn.Close();
            }

        }

        public bool checkSkind(string Fkind, string name)
        {
            MySqlConnection conn = DBUtils.open();
            String sql = "select name from skind where Fkind = '" + Fkind + "' and name = '" + name + "'";
            MySqlCommand cmd = new MySqlCommand(sql, conn);
            try
            {
                MySqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    Console.WriteLine(dr.GetString("name"));
                    return false;
                }
                else
                    return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("发生了不可描述的异常: " + ex.Message);
                return false;
            }
            finally
            {
                conn.Close();
            }

        }

        public Boolean delDis(string name)
        {
            MySqlConnection conn = DBUtils.open();
            String sql = "delete from discount where name = '" + name + "'";
            MySqlCommand cmd = new MySqlCommand(sql, conn);
            try
            {
                cmd.ExecuteNonQuery();
                upImToIm(name);
                upImToIn(name);
                return true;
            }
            catch (MySqlException ex)
            {
                return false;
            }
            finally
            {
                conn.Close();
            }
        }

        public String delete(String id)
        {
            MySqlConnection conn = DBUtils.open();
            String sql = "delete from inventory where id = " + id;
            MySqlCommand cmd = new MySqlCommand(sql, conn);
            try
            {
                cmd.ExecuteNonQuery();
                return "true";
            }
            catch (MySqlException ex)
            {
                return ex.Message;
            }
            finally
            {
                conn.Close();
            }
        }

        public string deleteKind(string name)
        {
            MySqlConnection conn = DBUtils.open();
            MySqlConnection conn_2 = DBUtils.open();
            String sql = "delete from kind where name = '" + name + "'";
            String sql_2 = "delete from skind where Fkind = '" + name + "'";
            MySqlCommand cmd = new MySqlCommand(sql, conn);
            MySqlCommand cmd_2 = new MySqlCommand(sql_2, conn);
            try
            {
                cmd.ExecuteNonQuery();
                cmd_2.ExecuteNonQuery();
                return "true";
            }
            catch (MySqlException ex)
            {
                return ex.Message;
            }
            finally
            {
                conn.Close();
                conn_2.Close();
            }
        }

        public string deleteSkind(String Fkind,String name)
        {
            MySqlConnection conn = DBUtils.open();
            String sql = "delete from skind where Fkind = '" + Fkind + "' and name = '" + name + "'";
            MySqlCommand cmd = new MySqlCommand(sql, conn);
            try
            {
                cmd.ExecuteNonQuery();
                return "true";
            }
            catch (MySqlException ex)
            {
                return ex.Message;
            }
            finally
            {
                conn.Close();
            }
        }

        public string[] querryBySkind(string Fkind, string name)
        {
            String sql = "select name from information where Fkind = '" + Fkind + "' and kind = '" + name + "'";
            MySqlConnection conn = DBUtils.open();
            MySqlConnection conn_2 = DBUtils.open();
            MySqlCommand cmd = new MySqlCommand(sql, conn);
            MySqlCommand cmd_2 = new MySqlCommand(sql, conn_2);
            int rsLen = 0;
            int i = 0;
            try
            {
                MySqlDataReader rs = cmd.ExecuteReader();
                MySqlDataReader rs_temp = cmd_2.ExecuteReader();
                while (rs_temp.Read())
                {
                    rsLen++;
                }
                Console.WriteLine(rsLen);

                String[] res = new String[rsLen];
                while (rs.Read())
                {
                    //MessageBox.Show(rs.GetString("name"));
                    res[i] = rs.GetString("name");
                    i++;
                }
                return res;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                String[] res = { ex.Message };
                return res;
            }
            finally
            {
                conn.Close();
                conn_2.Close();
            };
        }

        public void querryData()
        {
            MySqlConnection conn = DBUtils.open();
            String sql = "select * from inventory";
            MySqlCommand cmd = new MySqlCommand(sql, conn);
            try
            {
                MySqlDataReader rs = cmd.ExecuteReader();
                while (rs.Read())
                {
                    String state = "未支付";
                    if (rs.GetString("state").ToString() == "1")
                        state = "已支付";
                    String[] revbuf = { rs.GetInt32("id").ToString(), rs.GetString("code"), rs.GetString("name"), rs.GetString("spec"),rs.GetString("price"), rs.GetString("date"), state };
                    querryForm.qs.dataGridView1.Rows.Add(revbuf);
                    //dataGridView1.Rows.Add(revbuf);
                }
            }
            catch (MySqlException ex)
            {
                String[] rs = { ex.Message };
            }
            finally
            {
                conn.Close();
            };
        }

        public void querryDiscount()
        {
            DiscountForm.df.dataGridView1.Rows.Clear();
            MySqlConnection conn = DBUtils.open();
            String sql = "select * from discount";
            MySqlCommand cmd = new MySqlCommand(sql, conn);
            try
            {
                MySqlDataReader rs = cmd.ExecuteReader();
                while (rs.Read())
                {
                    String[] revbuf = { rs.GetString("name") , rs.GetString("Fprice"), rs.GetString("price") };
                    DiscountForm.df.dataGridView1.Rows.Add(revbuf);
                }
            }
            catch (MySqlException ex)
            {
                String[] rs = { ex.Message };
            }
            finally
            {
                conn.Close();
            };
        }

        public void querryKind()
        {
            kindForm.ks.dataGridView1.Rows.Clear();
            String sql = "select name from kind";
            MySqlConnection conn = DBUtils.open();
            MySqlCommand cmd = new MySqlCommand(sql, conn);
            try
            {
                MySqlDataReader rs = cmd.ExecuteReader();
                while (rs.Read())
                {
                    String name = rs.GetString("name");
                    kindForm.ks.dataGridView1.Rows.Add(name);
                }
            }
            catch (Exception ex)
            {
                String[] rs = { ex.Message };
            }
            finally
            {
                conn.Close();
            };
        }

        public String[] querryKind(string NULL)
        {
            String sql = "select name from kind";
            MySqlConnection conn = DBUtils.open();
            MySqlConnection conn_2 = DBUtils.open();
            MySqlCommand cmd = new MySqlCommand(sql, conn);
            MySqlCommand cmd_2 = new MySqlCommand(sql, conn_2);
            int rsLen = 0;
            int i = 0;
            try
            {
                MySqlDataReader rs = cmd.ExecuteReader();
                MySqlDataReader rs_temp = cmd_2.ExecuteReader();
                while (rs_temp.Read())
                {
                    rsLen++;
                }
                Console.WriteLine(rsLen);
                
                String[] res = new String[rsLen];
                while(rs.Read())
                {
                    //MessageBox.Show(rs.GetString("name"));
                    res[i] = rs.GetString("name");
                    i++;
                }
                return res;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                String[] res = { ex.Message };
                return res;
            }
            finally
            {
                conn.Close();
                conn_2.Close();
            };
        }

        public string querryOriPrice(string name)
        {
            String price = "";
            MySqlConnection conn = DBUtils.open();
            string sql = "select price from information_ori where name = '" + name + "'";
            MySqlCommand cmd = new MySqlCommand(sql, conn);
            try
            {
                MySqlDataReader rs = cmd.ExecuteReader();
                if (rs.Read())
                {
                    price = rs.GetString("price");
                    return price;
                }
                else
                {
                    MessageBox.Show("请检查商品信息是否完整");
                }
            }
            catch (MySqlException ex)
            {
                return ex.Message;
            }
            finally
            {
                conn.Close();
            }
            return null;
        }

        public string querryPrice(string name)
        {
            String price = "";
            MySqlConnection conn = DBUtils.open();
            string sql = "select price from information where name = '" + name + "'";
            MySqlCommand cmd = new MySqlCommand(sql, conn);
            try
            {
                MySqlDataReader rs = cmd.ExecuteReader();
                if (rs.Read())
                {
                    price = rs.GetString("price");
                    return price;
                }
                else
                {
                    MessageBox.Show("请检查商品信息是否完整");
                }
            }
            catch (MySqlException ex)
            {
                return ex.Message;
            }
            finally
            {
                conn.Close();
            }
            return null;
        }

        public void querrySkind(String Fkind)
        {
            SkindForm.sf.dataGridView1.Rows.Clear();
            String sql = "select name from skind where Fkind = '" + Fkind + "'";
            MySqlConnection conn = DBUtils.open();
            MySqlCommand cmd = new MySqlCommand(sql, conn);
            try
            {
                MySqlDataReader rs = cmd.ExecuteReader();
                while (rs.Read())
                {
                    String name = rs.GetString("name");
                    SkindForm.sf.dataGridView1.Rows.Add(name);
                }
            }
            catch (Exception ex)
            {
                String[] rs = { ex.Message };
            }
            finally
            {
                conn.Close();
            };

        }

        public String[] querrySkind(string Fkind, string NULL)
        {
            String sql = "select name from skind where Fkind = '" + Fkind + "'";
            MySqlConnection conn = DBUtils.open();
            MySqlConnection conn_2 = DBUtils.open();
            MySqlCommand cmd = new MySqlCommand(sql, conn);
            MySqlCommand cmd_2 = new MySqlCommand(sql, conn_2);
            int rsLen = 0;
            int i = 0;
            try
            {
                MySqlDataReader rs = cmd.ExecuteReader();
                MySqlDataReader rs_temp = cmd_2.ExecuteReader();
                while (rs_temp.Read())
                {
                    rsLen++;
                }
                Console.WriteLine(rsLen);

                String[] res = new String[rsLen];
                while (rs.Read())
                {
                    //MessageBox.Show(rs.GetString("name"));
                    res[i] = rs.GetString("name");
                    i++;
                }
                return res;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                String[] res = { ex.Message };
                return res;
            }
            finally
            {
                conn.Close();
                conn_2.Close();
            };
        }

        public bool querryState(String rfid)
        {
            MySqlConnection conn = DBUtils.open();
            String sql = "select state from inventory where rfid = '" + rfid + "'";
            MySqlCommand cmd = new MySqlCommand(sql, conn);
            try
            {
                MySqlDataReader rs = cmd.ExecuteReader();
                if (rs.Read())
                {
                    String state = rs.GetString("state");
                    Console.WriteLine(state);
                    if (state.Equals("0"))
                        return false;
                    else
                        return true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return true;
            }
            finally
            {
                conn.Close();
            }
            return true;
        }

        public String update(String id, String code, String name,String spec,String price)
        {
            MySqlConnection conn = DBUtils.open();
            MySqlConnection conn_2 = DBUtils.open();
            String sql = "select * from inventory where id = " + id;
            MySqlCommand cmd = new MySqlCommand(sql, conn);
            try
            {
                MySqlDataReader rs = cmd.ExecuteReader();
                rs.Read();
                if (code == "")
                {
                    MessageBox.Show(rs.GetString("code"));
                    code = rs.GetString("code");
                }
                if (name == "")
                {
                    MessageBox.Show(rs.GetString("name"));
                    name = rs.GetString("name");
                }
                if (spec == "")
                {
                    MessageBox.Show(rs.GetString("spec"));
                    spec = rs.GetString("spec");
                }
                if (price == "")
                {
                    price = rs.GetString("price");
                }
                conn.Close();
                sql = "update information set code = '" + code + "', name = '" + name + "', spec = '" + spec + "', price = '" + price + "' where id = " + id;
                MySqlCommand cmd_2 = new MySqlCommand(sql, conn_2);
                cmd_2.ExecuteNonQuery();
                return "true";
            }
            catch
            {
            }
            finally
            {
                conn.Close();
                conn_2.Close();
            }
            return null;
        }

        public bool upDpToIm(string name, string price)
        {
            String sql = "update information set price = '" + price + "' where name = '" + name + "'";
            MySqlConnection conn = DBUtils.open();
            MySqlCommand cmd = new MySqlCommand(sql, conn);
            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
            finally
            {
                conn.Close();
            }
        }

        public Boolean upDpToIn(string name, string price)
        {
            String sql = "update inventory set price = '" + price + "' where name = '" + name + "'";
            MySqlConnection conn = DBUtils.open();
            MySqlCommand cmd = new MySqlCommand(sql, conn);
            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
            finally
            {
                conn.Close();
            }
        }

        public bool upImToIm(string name)
        {
            String price = querryOriPrice(name);
            String sql = "update information set price = '" + price + "' where name = '" + name + "'";
            MySqlConnection conn = DBUtils.open();
            MySqlCommand cmd = new MySqlCommand(sql, conn);
            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
            finally
            {
                conn.Close();
            }
        }

        public Boolean upImToIn(string name)
        {
            String price = querryOriPrice(name);
            String sql = "update inventory set price = '" + price + "' where name = '" + name + "'";
            MySqlConnection conn = DBUtils.open();
            MySqlCommand cmd = new MySqlCommand(sql, conn);
            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
            finally
            {
                conn.Close();
            }
        }
    }
}