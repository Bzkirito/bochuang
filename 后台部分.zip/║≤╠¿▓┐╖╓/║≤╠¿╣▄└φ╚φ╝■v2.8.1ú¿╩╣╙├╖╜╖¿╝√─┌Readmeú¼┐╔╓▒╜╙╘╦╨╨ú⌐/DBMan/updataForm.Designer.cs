﻿namespace DBMan
{
    partial class updataForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.upName = new System.Windows.Forms.TextBox();
            this.upCode = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.upBtn = new System.Windows.Forms.Button();
            this.upID = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.upPri = new System.Windows.Forms.TextBox();
            this.upSpec = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // upName
            // 
            this.upName.Location = new System.Drawing.Point(390, 125);
            this.upName.Name = "upName";
            this.upName.Size = new System.Drawing.Size(100, 21);
            this.upName.TabIndex = 9;
            // 
            // upCode
            // 
            this.upCode.Location = new System.Drawing.Point(132, 125);
            this.upCode.Name = "upCode";
            this.upCode.Size = new System.Drawing.Size(100, 21);
            this.upCode.TabIndex = 8;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(55, 128);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 12);
            this.label2.TabIndex = 7;
            this.label2.Text = "商品编码 ：";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(313, 128);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 12);
            this.label1.TabIndex = 6;
            this.label1.Text = "商品名称 ：";
            // 
            // upBtn
            // 
            this.upBtn.Location = new System.Drawing.Point(217, 247);
            this.upBtn.Name = "upBtn";
            this.upBtn.Size = new System.Drawing.Size(117, 23);
            this.upBtn.TabIndex = 5;
            this.upBtn.Text = "修改";
            this.upBtn.UseVisualStyleBackColor = true;
            this.upBtn.Click += new System.EventHandler(this.upBtn_Click);
            // 
            // upID
            // 
            this.upID.Location = new System.Drawing.Point(167, 32);
            this.upID.Name = "upID";
            this.upID.Size = new System.Drawing.Size(100, 21);
            this.upID.TabIndex = 11;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 35);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(155, 12);
            this.label3.TabIndex = 10;
            this.label3.Text = "请输入您要修改的商品ID ：";
            // 
            // upPri
            // 
            this.upPri.Location = new System.Drawing.Point(390, 185);
            this.upPri.Name = "upPri";
            this.upPri.Size = new System.Drawing.Size(100, 21);
            this.upPri.TabIndex = 15;
            // 
            // upSpec
            // 
            this.upSpec.Location = new System.Drawing.Point(132, 185);
            this.upSpec.Name = "upSpec";
            this.upSpec.Size = new System.Drawing.Size(100, 21);
            this.upSpec.TabIndex = 14;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(55, 188);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(71, 12);
            this.label4.TabIndex = 13;
            this.label4.Text = "商品规格 ：";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(313, 188);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(71, 12);
            this.label5.TabIndex = 12;
            this.label5.Text = "商品价格 ：";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.upID);
            this.groupBox1.Location = new System.Drawing.Point(20, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(284, 77);
            this.groupBox1.TabIndex = 16;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Tips：";
            // 
            // updataForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(552, 296);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.upPri);
            this.Controls.Add(this.upSpec);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.upName);
            this.Controls.Add(this.upCode);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.upBtn);
            this.Name = "updataForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "updataForm";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox upName;
        private System.Windows.Forms.TextBox upCode;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button upBtn;
        private System.Windows.Forms.TextBox upID;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox upPri;
        private System.Windows.Forms.TextBox upSpec;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}