﻿namespace DBMan
{
    partial class addForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(addForm));
            this.addBtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.addCode = new System.Windows.Forms.TextBox();
            this.addName = new System.Windows.Forms.TextBox();
            this.addSpec = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.addPri = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label8 = new System.Windows.Forms.Label();
            this.QRCombo = new System.Windows.Forms.ComboBox();
            this.BoundRate = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.addShl = new System.Windows.Forms.TextBox();
            this.addFin = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.addRfid = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.addImg = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.addPortOpen = new System.Windows.Forms.Button();
            this.addPortClose = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.currentPort = new System.Windows.Forms.Label();
            this.autoBtn = new System.Windows.Forms.Button();
            this.modeLable = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.manual = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // addBtn
            // 
            this.addBtn.Location = new System.Drawing.Point(764, 478);
            this.addBtn.Name = "addBtn";
            this.addBtn.Size = new System.Drawing.Size(117, 23);
            this.addBtn.TabIndex = 0;
            this.addBtn.Text = "手动添加";
            this.addBtn.UseVisualStyleBackColor = true;
            this.addBtn.Click += new System.EventHandler(this.addBtn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(271, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 12);
            this.label1.TabIndex = 1;
            this.label1.Text = "商品名称 ：";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(29, 33);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 12);
            this.label2.TabIndex = 2;
            this.label2.Text = "商品编码 ：";
            // 
            // addCode
            // 
            this.addCode.Location = new System.Drawing.Point(106, 30);
            this.addCode.Name = "addCode";
            this.addCode.Size = new System.Drawing.Size(100, 21);
            this.addCode.TabIndex = 3;
            // 
            // addName
            // 
            this.addName.Location = new System.Drawing.Point(348, 30);
            this.addName.Name = "addName";
            this.addName.Size = new System.Drawing.Size(100, 21);
            this.addName.TabIndex = 4;
            // 
            // addSpec
            // 
            this.addSpec.Location = new System.Drawing.Point(106, 83);
            this.addSpec.Name = "addSpec";
            this.addSpec.Size = new System.Drawing.Size(100, 21);
            this.addSpec.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(29, 86);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(71, 12);
            this.label3.TabIndex = 5;
            this.label3.Text = "商品规格 ：";
            // 
            // addPri
            // 
            this.addPri.Location = new System.Drawing.Point(348, 83);
            this.addPri.Name = "addPri";
            this.addPri.Size = new System.Drawing.Size(100, 21);
            this.addPri.TabIndex = 8;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(271, 86);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(71, 12);
            this.label4.TabIndex = 7;
            this.label4.Text = "商品价格 ：";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.groupBox3);
            this.groupBox1.Controls.Add(this.addShl);
            this.groupBox1.Controls.Add(this.addFin);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.addPri);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.addSpec);
            this.groupBox1.Controls.Add(this.addCode);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.addName);
            this.groupBox1.Location = new System.Drawing.Point(12, 20);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(516, 319);
            this.groupBox1.TabIndex = 9;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "录入";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.QRCombo);
            this.groupBox3.Controls.Add(this.BoundRate);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.addPortOpen);
            this.groupBox3.Controls.Add(this.addPortClose);
            this.groupBox3.Location = new System.Drawing.Point(0, 175);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(516, 144);
            this.groupBox3.TabIndex = 24;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "串口设置";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(29, 37);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(71, 12);
            this.label8.TabIndex = 23;
            this.label8.Text = "串口选择 ：";
            // 
            // QRCombo
            // 
            this.QRCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.QRCombo.FormattingEnabled = true;
            this.QRCombo.Location = new System.Drawing.Point(106, 34);
            this.QRCombo.Name = "QRCombo";
            this.QRCombo.Size = new System.Drawing.Size(100, 20);
            this.QRCombo.TabIndex = 20;
            this.QRCombo.SelectedIndexChanged += new System.EventHandler(this.QRCombo_SelectedIndexChanged);
            // 
            // BoundRate
            // 
            this.BoundRate.FormattingEnabled = true;
            this.BoundRate.Items.AddRange(new object[] {
            "9600",
            "115200"});
            this.BoundRate.Location = new System.Drawing.Point(348, 34);
            this.BoundRate.Name = "BoundRate";
            this.BoundRate.Size = new System.Drawing.Size(100, 20);
            this.BoundRate.TabIndex = 22;
            this.BoundRate.Text = "115200";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(271, 37);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(59, 12);
            this.label7.TabIndex = 21;
            this.label7.Text = "波特率 ：";
            // 
            // addShl
            // 
            this.addShl.Location = new System.Drawing.Point(348, 135);
            this.addShl.Name = "addShl";
            this.addShl.Size = new System.Drawing.Size(100, 21);
            this.addShl.TabIndex = 11;
            // 
            // addFin
            // 
            this.addFin.Location = new System.Drawing.Point(106, 135);
            this.addFin.Name = "addFin";
            this.addFin.Size = new System.Drawing.Size(100, 21);
            this.addFin.TabIndex = 10;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(271, 138);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(71, 12);
            this.label6.TabIndex = 10;
            this.label6.Text = "货架号   ：";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(29, 138);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(71, 12);
            this.label5.TabIndex = 9;
            this.label5.Text = "保质期   ：";
            // 
            // addRfid
            // 
            this.addRfid.AutoSize = true;
            this.addRfid.Location = new System.Drawing.Point(364, 369);
            this.addRfid.Name = "addRfid";
            this.addRfid.Size = new System.Drawing.Size(29, 12);
            this.addRfid.TabIndex = 13;
            this.addRfid.Text = "NULL";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(289, 369);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(59, 12);
            this.label10.TabIndex = 12;
            this.label10.Text = "标签码 ：";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(20, 33);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(435, 343);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 14;
            this.pictureBox1.TabStop = false;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.pictureBox1);
            this.groupBox2.Location = new System.Drawing.Point(578, 20);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(475, 394);
            this.groupBox2.TabIndex = 15;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "预览";
            // 
            // addImg
            // 
            this.addImg.AutoSize = true;
            this.addImg.Location = new System.Drawing.Point(88, 369);
            this.addImg.Name = "addImg";
            this.addImg.Size = new System.Drawing.Size(29, 12);
            this.addImg.TabIndex = 17;
            this.addImg.Text = "NULL";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(41, 369);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(41, 12);
            this.label12.TabIndex = 16;
            this.label12.Text = "img ：";
            // 
            // serialPort1
            // 
            this.serialPort1.PortName = "COM4";
            this.serialPort1.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.serialPort1_DataReceived);
            // 
            // addPortOpen
            // 
            this.addPortOpen.Location = new System.Drawing.Point(49, 99);
            this.addPortOpen.Name = "addPortOpen";
            this.addPortOpen.Size = new System.Drawing.Size(117, 23);
            this.addPortOpen.TabIndex = 18;
            this.addPortOpen.Text = "打开串口";
            this.addPortOpen.UseVisualStyleBackColor = true;
            this.addPortOpen.Click += new System.EventHandler(this.addPortOpen_Click);
            // 
            // addPortClose
            // 
            this.addPortClose.Location = new System.Drawing.Point(331, 99);
            this.addPortClose.Name = "addPortClose";
            this.addPortClose.Size = new System.Drawing.Size(117, 23);
            this.addPortClose.TabIndex = 19;
            this.addPortClose.Text = "关闭串口";
            this.addPortClose.UseVisualStyleBackColor = true;
            this.addPortClose.Click += new System.EventHandler(this.addPortClose_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(33, 419);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(65, 12);
            this.label9.TabIndex = 20;
            this.label9.Text = "当前串口：";
            // 
            // currentPort
            // 
            this.currentPort.AutoSize = true;
            this.currentPort.Location = new System.Drawing.Point(108, 419);
            this.currentPort.Name = "currentPort";
            this.currentPort.Size = new System.Drawing.Size(29, 12);
            this.currentPort.TabIndex = 21;
            this.currentPort.Text = "NULL";
            // 
            // autoBtn
            // 
            this.autoBtn.Location = new System.Drawing.Point(61, 478);
            this.autoBtn.Name = "autoBtn";
            this.autoBtn.Size = new System.Drawing.Size(117, 23);
            this.autoBtn.TabIndex = 22;
            this.autoBtn.Text = "自动模式";
            this.autoBtn.UseVisualStyleBackColor = true;
            this.autoBtn.Click += new System.EventHandler(this.autoBtn_Click);
            // 
            // modeLable
            // 
            this.modeLable.AutoSize = true;
            this.modeLable.Location = new System.Drawing.Point(358, 419);
            this.modeLable.Name = "modeLable";
            this.modeLable.Size = new System.Drawing.Size(53, 12);
            this.modeLable.TabIndex = 24;
            this.modeLable.Text = "自动模式";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(283, 419);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(65, 12);
            this.label13.TabIndex = 23;
            this.label13.Text = "当前模式：";
            // 
            // manual
            // 
            this.manual.Location = new System.Drawing.Point(343, 478);
            this.manual.Name = "manual";
            this.manual.Size = new System.Drawing.Size(117, 23);
            this.manual.TabIndex = 25;
            this.manual.Text = "手动模式";
            this.manual.UseVisualStyleBackColor = true;
            this.manual.Click += new System.EventHandler(this.manual_Click);
            // 
            // addForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1072, 513);
            this.Controls.Add(this.manual);
            this.Controls.Add(this.modeLable);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.autoBtn);
            this.Controls.Add(this.currentPort);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.addImg);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.addRfid);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.addBtn);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "addForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "add";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.addForm_FormClosed);
            this.Load += new System.EventHandler(this.addForm_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button addBtn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox addCode;
        private System.Windows.Forms.TextBox addName;
        private System.Windows.Forms.TextBox addSpec;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox addPri;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox addFin;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox addShl;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label addRfid;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label12;
        public System.Windows.Forms.PictureBox pictureBox1;
        private System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.Button addPortOpen;
        private System.Windows.Forms.Button addPortClose;
        public System.Windows.Forms.Label addImg;
        private System.Windows.Forms.ComboBox QRCombo;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox BoundRate;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label currentPort;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button autoBtn;
        private System.Windows.Forms.Label modeLable;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button manual;
    }
}