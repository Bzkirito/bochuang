﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.IO.Ports;
using System.Threading;                                                                  

namespace DBMan
{
    public partial class DBM : Form
    {
        public DBM()
        {
            InitializeComponent();
        }

        private void addBtn_Click(object sender, EventArgs e)
        {
            addForm af = new addForm();
            af.ShowDialog();
        }

        private void delBtn_Click(object sender, EventArgs e)
        {
            delFrom df = new delFrom();
            df.Show();
        }

        private void upBtn_Click(object sender, EventArgs e)
        {
            updataForm uf = new updataForm();
            uf.Show();
        }

        private void traBtn_Click(object sender, EventArgs e)
        {
            querryForm qf = new querryForm();
            qf.Show();
        }

        private void kindBtn_Click(object sender, EventArgs e)
        {
            kindForm kf = new kindForm();
            kf.Show();
        }

        private void Discount_Click(object sender, EventArgs e)
        {
            DiscountForm df = new DiscountForm();
            df.Show();
        }

        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            Thread.Sleep(20);
            string str = "";
            do
            {
                int count = serialPort1.BytesToRead;
                Console.WriteLine("count:"+count);
                if (count <= 0)
                    break;
                char[] readBuffer = new char[count];
                Application.DoEvents();
                serialPort1.Read(readBuffer, 0, count);
                for (int i = 0; i < readBuffer.Length; i++)
                    str += readBuffer[i];
            } while (serialPort1.BytesToRead > 0);
            string[] strArray = str.Split(new string[] { "+" }, StringSplitOptions.RemoveEmptyEntries);
            //Console.WriteLine(strArray[0]);
            str = strArray[0];
            //MessageBox.Show(str);
            str = str.Replace("\r", "");
            str = str.Replace("\n", "");
            str = str.Replace(" ", "");
            Console.WriteLine("re:"+str);

            DAOInterface querry = new sqlDAO();
            if (querry.querryState(str))
            {
                if (Open())
                {
                    try
                    {
                        serialPort1.Write("1\r\n");
                        Console.WriteLine("1");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("串口发送异常：" + ex.Message);
                    }
                }
            }

            else
            {
                if (Open())
                {
                    try
                    {
                        serialPort1.Write("0\r\n");
                        Console.WriteLine("0");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("串口发送异常：" + ex.Message);
                    }
                }
            }
        }

 /*       private void port()
        {
            string[] PortNames = SerialPort.GetPortNames();

            serialPort1.Close();
            serialPort1.PortName = PortNames[0];
            serialPort1.BaudRate = 115200;
            try
            {
                serialPort1.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
*/    

        private void DBM_Load(object sender, EventArgs e)
        {
            serialPort1.Close();
            string[] PortNames = SerialPort.GetPortNames();
            for (int i = 0; i < PortNames.Length; i++)
            {
                comCom.Items.Add(PortNames[i]);
            }

        }

        public bool Open()
        {

            try
            {
                if (!serialPort1.IsOpen)
                {
                    serialPort1.Open();
                    return true;
                }
                else
                {
                    return true;
                }
            }
            catch (Exception ex)
            {
                return false;
            }

        }

        private void OpenMonitor_Click(object sender, EventArgs e)
        {
            serialPort1.Close();
            try
            {
                if (comCom.Text == "")
                {
                    MessageBox.Show("请选择串口");
                    return;
                }
                serialPort1.PortName = comCom.Text;
                state.Text = "监控运行中";
            }
            catch (Exception ex)
            {
                MessageBox.Show("串口检测失败");
                return;
            }
            serialPort1.BaudRate = int.Parse(BoundRate.Text);
            try
            {
                serialPort1.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void CloseMonitor_Click(object sender, EventArgs e)
        {
            try
            {
                serialPort1.Close();
                state.Text = "监控已关闭";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            comCom.Items.Clear();
            string[] PortNames = SerialPort.GetPortNames();
            for (int i = 0; i < PortNames.Length; i++)
            {
                comCom.Items.Add(PortNames[i]);
            }
        }

    }
}
