﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace DBMan
{
    public partial class delFrom : Form
    {
        public delFrom()
        {
            InitializeComponent();
        }

        private void delBtn_Click(object sender, EventArgs e)
        {
            sqlDAO del = new sqlDAO();
            String rs = del.delete(delID.Text.ToString());
            if (rs == "true")
            {
                MessageBox.Show("删除成功");
                this.Close();
            }
            else
            {
                MessageBox.Show(rs);
            }
        }
    }
}
