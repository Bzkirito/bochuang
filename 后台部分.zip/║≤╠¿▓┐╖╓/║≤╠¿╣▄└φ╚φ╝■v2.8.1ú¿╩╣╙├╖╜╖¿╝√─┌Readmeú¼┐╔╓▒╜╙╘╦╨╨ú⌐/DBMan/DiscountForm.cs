﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace DBMan
{
    public partial class DiscountForm : Form
    {
        public static DiscountForm df;
        public DiscountForm()
        {
            InitializeComponent();
            df = this;
        }

        private void kindBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            skindBox.Items.Clear();
            skindBox.Text = "";
            goodBox.Text = "";
            DAOInterface skind = new sqlDAO();
            String[] res = skind.querrySkind(kindBox.Text, "null");
            for (int i = 0; i < res.Length; i++)
            {
                skindBox.Items.Add(res[i]);
            }
        }

        private void DiscountForm_Load(object sender, EventArgs e)
        {
            DataGridView();
            DAOInterface kind = new sqlDAO();
            String[] res = kind.querryKind("null");
            for (int i = 0; i < res.Length; i++)
            {
                kindBox.Items.Add(res[i]);
            }
        }

        private void skindBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            goodBox.Items.Clear();
            goodBox.Text = "";
            DAOInterface kind = new sqlDAO();
            String[] res = kind.querryBySkind(kindBox.Text, skindBox.Text);
            for (int i = 0; i < res.Length; i++)
            {
                goodBox.Items.Add(res[i]);
            }
        }

        private void DataGridView()
        {
            DAOInterface dv = new sqlDAO();
            dv.querryDiscount();
        }

        private void goodBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            DAOInterface dv = new sqlDAO();
            FpLable.Text = dv.querryPrice(goodBox.Text);
        }

        private void DisBtn_Click(object sender, EventArgs e)
        {
            DAOInterface dv = new sqlDAO();
            if (dv.checkDis(goodBox.Text))
            {
                MessageBox.Show("优惠已存在");
                return;
            }
            dv.addDis(kindBox.Text, skindBox.Text, goodBox.Text, priceBox.Text);
            goodBox.Text = "";
            priceBox.Text = "";
            dv.querryDiscount(); 
        }

        private void canDis_Click(object sender, EventArgs e)
        {
            DAOInterface di = new sqlDAO();
            di.delDis(goodBox.Text);
            goodBox.Text = "";
            di.querryDiscount();
        }

        private void dataGridView1_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            try
            {
                String name = dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString();
                goodBox.Text = name;
            }
            catch
            {
            }
        }
    }
}
