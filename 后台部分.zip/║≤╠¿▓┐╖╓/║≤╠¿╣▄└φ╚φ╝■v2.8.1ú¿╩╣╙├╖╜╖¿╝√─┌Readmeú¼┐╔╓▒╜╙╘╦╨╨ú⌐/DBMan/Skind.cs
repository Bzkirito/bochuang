﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBMan
{
    public partial class SkindForm : Form
    {
        String kindName;
        public static SkindForm sf;
        public SkindForm()
        {
            InitializeComponent();
            sf = this;
        }
        public SkindForm(String kindName)
        {
            InitializeComponent();
            sf = this;
            this.kindName = kindName;
        }

        private void SkindForm_Load(object sender, EventArgs e)
        {
            DAOInterface sd = new sqlDAO();
            sd.querrySkind(kindName);
        }

        private void addSkindBtn_Click(object sender, EventArgs e)
        {
            if (addSkind.Text == "")
                return;
            DAOInterface ad = new sqlDAO();
            String state = ad.addSkind(kindName,addSkind.Text.ToString());
            if (state == "true")
            {
                MessageBox.Show("添加成功");
                addSkind.Text = "";
            }
            else
                MessageBox.Show("添加失败，存在同名种类");
            ad.querrySkind(kindName);
        }

        private void delKindBtn_Click(object sender, EventArgs e)
        {
            if (SkindDel.Text == "")
                return;
            DAOInterface ad = new sqlDAO();
            ad.deleteSkind(kindName,SkindDel.Text);
            ad.querrySkind(kindName);
        }

        private void SkindForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.DialogResult = DialogResult.OK;
        }

        private void dataGridView1_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            try
            {
                String name = dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString();
                SkindDel.Text = name;
            }
            catch (Exception ex)
            {
            }
        }
    }
}