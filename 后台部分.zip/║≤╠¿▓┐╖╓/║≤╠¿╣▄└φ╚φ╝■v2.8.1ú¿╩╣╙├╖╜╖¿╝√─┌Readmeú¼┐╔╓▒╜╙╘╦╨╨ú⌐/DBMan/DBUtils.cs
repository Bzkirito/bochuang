﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Windows.Forms;


namespace DBMan
{
    class DBUtils
    {
        public static MySqlConnection open()
        {
            String connStr = "server=localhost;port=3306;user=root;password=; database=bcb;";
            MySqlConnection conn = new MySqlConnection(connStr);
            try
            {
                conn.Open();
                //MessageBox.Show("A connection has been create!");
                return conn;
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
                return null;
            }
        }
    }
}
